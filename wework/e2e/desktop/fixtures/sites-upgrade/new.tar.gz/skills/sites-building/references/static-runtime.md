# Static runtimes

## HTML

Provide an accessible `index.html` and keep every local asset reference valid. Use native CSS and
JavaScript unless a framework adds real value. Static navigation must work without a server-side
router.

## React/Vite

Phase 0 templates use npm and a committed `package-lock.json`. Provide a `build` script and a
deterministic `dist` output. Browser requests to backend APIs use relative `/api` URLs. Do not use
CDN-loaded build dependencies.

## Runtime environment

For `html`, `react-vite`, and detected Vue static profiles, the Platform injects a synchronous
`/__wegent/runtime-env.js` before application scripts in every published HTML document. Read the
frozen browser global directly:

```js
const apiBase = globalThis.__WEGENT_ENV__?.API_BASE;
```

Declare every consumed key in `.wegent/hosting.json` `required_env`, but never place values there.
Do not use `process.env`, Vite `import.meta.env`, source replacement, or build arguments for these
Project environment variables; the immutable static artifact is built before a Deployment selects
its environment revision.

A missing key evaluates to `undefined` and must not prevent the page from loading. Check the value
before using it, render a safe feature-level "not configured" state, and skip the dependent network
request. Do not substitute a guessed URL, credential, or production-like placeholder. Missing
configuration remains non-blocking for publishing so that the first successful production publish
can make the Project available in Wework Applications; after the user configures it there, a second
normal publish selects the new environment revision.

Plain and Secret values have the same browser visibility in a static site. A configured Secret is
hidden from MCP, management reads, logs, and source, but every authorized site visitor can inspect
it through browser developer tools or the runtime script response. Use static Secrets only when
that visibility is acceptable for the internal audience. If a site may be loaded by untrusted or
public users, move the sensitive operation to a dynamic backend instead of using a static Secret.

`/__wegent` is reserved by the Platform. Never create that source or build-output directory. Do not
copy runtime values into URLs, logs, local/session storage, IndexedDB, analytics, or rendered error
messages. Environment changes require a normal new Deployment; do not implement client polling or
hot reload for the runtime script.
