# Authentication

Do not create a project-local username/password system. For published intranet (`inner`)
applications that require login, the OpenResty gateway injects the `X-SITES-USERNAME` request
header with the authenticated user's email prefix: `alice@example.com` becomes `alice`.
This is a username, not a full email address or an access token. Do not invent an email domain.

Read the header on the application backend. For example, a FastAPI app can expose the current
user to its frontend through a same-origin endpoint:

```python
from fastapi import HTTPException, Request

@app.get("/api/me")
def current_user(request: Request):
    username = request.headers.get("X-SITES-USERNAME", "").strip()
    if not username:
        raise HTTPException(status_code=401, detail="Login required")
    return {"username": username}
```

Browser JavaScript cannot directly read this incoming request header. When the UI needs the
current user, use a backend endpoint such as `/api/me`; do not have the frontend supply its own
identity header. Static-only `html` and `react-vite` profiles need a trusted backend API for this
feature; use `fastapi` or `react-fastapi` when implementing that API in the application.

Trust this identity only behind the trusted gateway with user-supplied copies stripped or
overwritten and direct backend access restricted. The header identifies the user; application
code must still enforce any business permissions required by the feature.

Do not assume the header exists for anonymous (`audience=all`) access, `outer` publication,
local preview, or requests that bypass the login gateway. For operations that require a user,
reject a missing or empty identity instead of defaulting to the owner or an administrator.
Keep public endpoints such as `/health` independent of identity. Treat authentication as
unavailable during local preview unless an explicit mock identity mode is clearly isolated
from production.
