#!/usr/bin/env python3
"""Initialize a Wegent Sites project without requiring Bash utilities."""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path
from typing import Union


PROFILES = ("html", "react-vite", "fastapi", "react-fastapi")
SCRIPT_DIRECTORY = Path(__file__).resolve().parent
TEMPLATES_DIRECTORY = SCRIPT_DIRECTORY.parent / "templates"


def initialize_site(profile: str, target_value: Union[str, Path]) -> Path:
    if profile not in PROFILES:
        raise ValueError(f"unsupported profile: {profile}")

    target = Path(target_value).expanduser().resolve()
    if target.exists():
        if not target.is_dir():
            raise ValueError(f"target path is not a directory: {target}")
        if any(target.iterdir()):
            raise ValueError(f"target directory must be absent or empty: {target}")

    template = TEMPLATES_DIRECTORY / profile
    if not template.is_dir():
        raise ValueError(f"template directory is unavailable: {template}")

    target.mkdir(parents=True, exist_ok=True)
    shutil.copytree(template, target, dirs_exist_ok=True)
    return target


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--profile", required=True, choices=PROFILES)
    parser.add_argument("directory")
    arguments = parser.parse_args()
    try:
        target = initialize_site(arguments.profile, arguments.directory)
    except ValueError as error:
        parser.error(str(error))
    print(f"initialized {arguments.profile} project at {target}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
