# Project contract

`.wegent/hosting.json` uses `contracts/project-contract.schema.json`. Standard templates need only
`schema_version`, `project_id`, `runtime_profile`, and `required_env`. Use `overrides` only to remove
real ambiguity in an adopted project. Never place shell commands, Docker flags, credentials, host
paths, or arbitrary capabilities in the contract.

The only first-release project capability is `capabilities.mysql`, valid for `fastapi` and
`react-fastapi` projects. Declare it only when durable MySQL storage is required. If
`schema_file` is present, it must be a safe project-relative path and should usually be
`.wegent/mysql/schema.json`.

`validate-project.py` creates `.wegent/build-manifest.json`. The manifest is generated evidence,
not a user-maintained build script. The platform must re-detect source and reject disagreement with
`CONTRACT_INCOMPATIBLE` rather than trusting the client manifest.

`required_env` is advisory metadata used to explain which runtime configuration a project expects.
Do not block validation, building, or deployment merely because a declared key is not configured.
Never add values to this file. Dynamic profiles read configured values from process environment;
static profiles read them from the Platform-injected `globalThis.__WEGENT_ENV__` browser object.
Missing custom values must not prevent the application from starting or passing its health check.
Keep the affected feature unavailable until configured instead of substituting a fabricated value.
Because a new Project may be absent from Wework Applications until its first successful production
publish, complete that publish before directing the user there to configure missing keys.
