# Deployment recovery

Build failure never advances to deployment. Static MVP rollback downloads the historical artifact
and runs the same backup/replace/restore publisher. Dynamic MVP rollback recreates the application
from the historical image digest and may have a downtime window. A failed dynamic deployment must
retain the previous digest and the Deployment's snapshotted environment revision for a compensation
attempt. Every rollback is
a new Deployment record; never rewrite history.

For `outer` deployments, `deploy_site_version` returning a Deployment is only acceptance of the
publish request. Continue polling `get_deployment_status` with the returned `deployment_id`.
`requested` and `policy_check` mean the security or publish check is still running; this may take a
long time and is not a failure. `provisioning`, `health_check`, and `switching` mean the audit passed
and publishing or traffic switching is in progress. Only `succeeded` means the external site is
published. If `failed` has `failure.code="SECURITY_REJECTED"`, the security audit rejected the
external publish and the project must not be treated as externally published.

A failed Deployment with `failure.code="NEED_SYNC_TO_LATEST"` means another successful production
Deployment became current before traffic switching. It is recoverable, not terminal for the user's
overall publish request. Use the structured `failure.details` instead of parsing the message. For an
active edit session, sync its original local changes against `details.latest` using the original
production base, automatically resolve deterministic three-way conflicts, and ask the user only for
uncertain semantic conflicts through `resolve_edit_conflicts`. Validate and push the new head, obtain
a fresh production confirmation, and publish a new Version and Deployment. For an explicitly chosen
immutable Version outside an edit session, submit a new Deployment after refreshing current
production state. Never retry or mutate the failed Deployment, and never reuse its idempotency key or
publish confirmation. Bound repeated production-advance recovery to three attempts before asking the
user whether to continue.
