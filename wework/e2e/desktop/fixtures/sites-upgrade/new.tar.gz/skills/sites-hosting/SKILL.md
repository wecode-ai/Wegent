---
name: sites-hosting
description: Save immutable versions and deploy or roll back projects through Wegent Sites. Always use after sites-building when the user asks to save, publish, deploy, inspect, or roll back a site.
---

# Wegent Sites Hosting

This skill orchestrates the `wegent_apps` MCP tools for the Wegent Sites app/connector. The plugin
never calls the platform REST API directly and never substitutes `curl` when the connector is
unavailable.

Treat the platform connector tool descriptions and this shipped `plugin/` payload as the runtime
source of truth. Repository-level `contracts/` files are development-time alignment material only;
they are not shipped with the plugin and must not be required during a real publish.

## Invariants

1. Saving a version does not deploy it.
2. A Version is immutable and references a successful Build and immutable Artifact.
3. A Deployment references a Version; it never publishes a mutable directory or image tag.
4. Stable URLs belong to the Project.
5. Identity and permission come from trusted service credentials, never tool arguments such as
   `username` or `skip_security_check`.
6. Environment values are Project-scoped and management-REST-only. MCP exposes status metadata,
   never Plain or Secret values, and deployment requests never choose an environment revision.
7. `get_site.inner_access_confirmation_required` is authoritative for whether an inner production
   publish must ask for access settings. Do not infer this from deployment IDs or local state.

## Workflow

1. Call `get_capabilities`. This plugin supports baseline contract majors `2` and `3`; parse
   `baseline_contract_version` and stop with an actionable upgrade message if it is missing,
   malformed, or has an unsupported major. Before starting, verify that the tools required by the selected
   path are present in `baseline_tools` or the applicable optional capability. Do not begin local or
   remote mutations and discover a missing tool halfway through the deployment.
2. If `.wegent/hosting.json` already has a `project_id`, call `get_site` and reuse that Project. A
   `NOT_FOUND` result means the binding is stale or inaccessible; do not silently create a duplicate
   Project. If the file has no Project and the user is creating a new site, call `create_site` once
   with a stable idempotency key, omit `audience` and `subjects`, and write the returned `project_id`
   to `.wegent/hosting.json`.
3. Run `scripts/validate-project.py <directory>` after any `project_id` or contract edits. Require a
   successful local validation result and generated build manifest for the exact files that will be
   saved.
4. If `.wegent/hosting.json` enables `capabilities.mysql`, call `get_mysql_capability`; stop if it is
   disabled or does not support the detected runtime profile or schema version.
5. For MySQL projects, call `ensure_mysql_binding`. If a schema file is declared, read it, then call
   `plan_mysql_schema`. Explain non-empty changes or warnings when review is useful, and call
   `apply_mysql_schema` before saving the source revision. Use stable idempotency keys for binding
   and schema writes. Do not continue to source save if the MySQL plan/apply step fails.
6. `start_edit_session` always starts a new edit session; it does not discover an older session. If
   this task already knows an `edit_session_id`, call `get_edit_session` first and reuse it when it is
   accessible and unexpired. Otherwise call `start_edit_session` once with a stable idempotency key
   and retain its response for the rest of the task. Inspect `structuredContent.credentials` before
   any Git operation. When it contains `auth_mode`, `remote_url`, `branch`, `username`, `token`, and
   a future `token_expires_at`, reuse those exact credentials until expiry and do not call
   `issue_edit_credentials`. Call `issue_edit_credentials` when advertised by capabilities, or the
   compatibility `get_edit_credentials` tool on older platforms, only when credentials are absent,
   expired, or `checkout_edit_session`, `fetch_edit_session`, or `push_edit_session` returns
   `GIT_AUTH_FAILED` after attaching them. Never issue credentials in response to an unauthenticated
   Git attempt or another Git error. The user should not see repository, branch, token, or workspace
   terminology; present this only as "editing the project".
7. Never run raw Git network commands directly for a platform-managed edit session.
   Use the local deterministic Git tools and pass the unmodified credential fields returned by the
   platform. For a new project whose local source was just created by `sites-building`, keep the
   generated local source, initialize it on the exact credential `branch`, commit locally, then call
   `push_edit_session` with the exact local HEAD as `expected_head_sha`; do not clone an empty branch over it. For a
   second-development session, call `checkout_edit_session` before editing. Call
   `fetch_edit_session` to refresh the current edit branch and only the exact `sources/*` refs
   returned by platform sync metadata. After applying changes, validate and commit locally, then
   call `push_edit_session` with the exact local HEAD. The local tools inject authentication only
   for their Git subprocess, never save it in a remote URL or Git configuration, and restrict writes
   to the credential's exact edit branch. Filesystem access remains governed by the runtime sandbox
   and approval policy. Never pass a
   caller-invented repository, branch, source ref, or refspec.
8. Treat `CREDENTIAL_EXPIRED` and `GIT_AUTH_FAILED` as the only local Git errors that permit one
   credential refresh. `DESTINATION_NOT_EMPTY`, `PATH_NOT_FOUND`, `REF_NOT_ALLOWED`,
   `BRANCH_MISMATCH`, `HEAD_MISMATCH`, `WORKTREE_NOT_CLEAN`, `NON_FAST_FORWARD`, and
   `GIT_PERMISSION_DENIED` require fixing their stated cause without issuing another credential.
   After pushing, proceed to the selected deploy action, or call a platform-advertised
   `check_edit_session_sync`/compatibility `sync_edit_session` tool when available. If the platform
   returns `NEED_SYNC_TO_LATEST`, fetch the returned latest source ref, merge or rebase it into the
   local edit branch, run validation again, commit the resolved result, and push the same edit branch.
   Attempt deterministic conflict resolution in code. For uncertain conflicts, call
   `resolve_edit_conflicts` and apply the user's choices before committing and pushing a
   conflict-resolution commit. The platform is the final gate, but the plugin performs the code merge.
9. Unless the user already made the deployment intent explicit, call
   `choose_edit_session_deploy_action` after pushing and any required sync, with the current
   `headCommitSha`. A generic request such as "publish", "deploy", "发布", or "部署" by itself is not
   explicit production intent; it must show the sibling action picker. Treat production intent as
   explicit only when the user specifically asks for production/formal release, for example
   "publish to production", "formal publish", "正式发布", "发生产", or "发布到生产". Let the user
   choose one of three sibling actions: preview, preprod, or formal publish. This picker selects a
   route and does not replace the signed production confirmation required by the Platform. For
   formal publish, resolve the production `target` first. For `inner`, complete the access gate in
   steps 15-16 before preparing the signed publish confirmation. If capabilities
   advertise `signed_publish_confirmations`, call `prepare_publish_edit_session` with the current
   `head_commit_sha`, then call `confirm_edit_session_publish` with the returned
   `confirmation_id`, `expires_at`, and summary fields. Continue only when that form returns
   `status="confirmed"`, and pass the returned `confirmation_id` to `publish_edit_session`.
   If the Platform advertises an incompatible contract major, stop and ask the user to update the
   installed plugin; do not fall back to the removed MCP environment-value workflow.
10. For preview, call `preview_edit_session` with the current `head_commit_sha`. Omit
   `environment_revision_id`; contract v2 does not accept it. The Platform transactionally selects
   the latest complete Project environment revision or an empty environment. The tool may return
   `build_queued` or `building`; poll `get_build_status` for the
   returned `build_id`, then retry `preview_edit_session` with the same idempotency key until it
   returns `preview_ready` with a `deployment_id`. Stop after a successful preview unless the user
   explicitly asks for another action. If the user asks to remove a temporary preview, call
   `delete_preview` for that preview deployment.
11. For preprod from fresh edit-session work, call `preprod_edit_session`, not
   `deploy_site_preprod`. Pass the current `head_commit_sha`; do not pass
   `environment_revision_id`. If it returns `BUILD_NOT_READY`, poll
   `get_build_status` for the returned `build_id`, then retry `preprod_edit_session` with the same
   idempotency key after the build succeeds. For preprod deployment of an existing visible release
   Version outside an edit session, continue to call `deploy_site_preprod`.
12. For previewing an existing visible Version outside an edit session, call `create_preview`.
13. If the user approves a preprod or preview deployment for production and no further source edits
   are needed, publish through the edit-session production path when an edit session is still active;
   otherwise call `promote_deployment`. Do not reuse preview runtime or preview MySQL data as
   production runtime/data.
14. When `required_env` is non-empty, call `get_environment_variable_status` once and compute
   missing keys as `required_env` minus the returned `configured_keys`. Treat configured keys as
   value-free status only. A missing key or a status-read failure is advisory: do not stop, pause,
   ask the user to configure it first, or skip any requested build or deployment action. In
   particular, a new Project may be absent from Wework Applications until its first production
   publish succeeds. Complete the requested flow with the latest complete Project environment
   revision or the Platform-selected empty environment. After a successful production publish,
   report any missing key names and use the returned `configuration_url` to direct the user to
   Wework Applications; if status could not be read, state only that configuration was not verified.
   Never fetch, scrape, or submit that page. Explain that saving configuration does not mutate the
   running Deployment and that the user must publish again for it to take effect. For static
   profiles, also explain that Plain and Secret values are injected into
   `globalThis.__WEGENT_ENV__` and are visible to browser users. Confirm that this is acceptable for
   the intended internal audience; otherwise move the sensitive operation to a dynamic backend
   before publishing.
15. Immediately before an inner production deployment, refresh the Project with `get_site`. If
   `inner_access_confirmation_required` is `false`, do not call `confirm_inner_site_access` or
   `update_site_access`; publish with the existing access policy unchanged. If the field is missing,
   stop because the Platform contract is incompatible instead of guessing from
   `latest_deployment_id`. If it is `true`, call `confirm_inner_site_access`. The first form defaults
   to `all` / “所有人（免登录）” and also offers `login` / “登录用户”, `owner` / “仅项目成员”, and
   `custom` / “指定人”. Project owners and current collaborators can access every mode. If the user
   chooses `custom`, the tool asks for comma-separated usernames in a second form. If the user
   cancels or the tool returns anything other than `status="confirmed"`, stop without deploying.
16. Only when `inner_access_confirmation_required` is `true` and access was confirmed, call
   `update_site_access` for `target="inner"` with the selected `audience`. Pass `subjects` only for
   `audience="custom"`; omit it for `all`, `login`, and `owner`. A successful update clears the
   confirmation requirement even if the following deployment fails, so later publishes keep this
   policy without asking again. The Platform selects the latest inner access policy and Project
   environment revision and snapshots both onto the Deployment.
17. Outer deployments and outer access changes do not use the inner access confirmation form. The
    platform is authoritative for caller permissions, access policy changes, and `outer` security
    audit gates.
18. Publish fresh edit-session work with `publish_edit_session`, not `deploy_site_version`. This
   checks latest production and returns `NEED_SYNC_TO_LATEST` when the edit branch is stale;
   after the plugin syncs and pushes a new head, it materializes the current source, reuses or
   creates the Build, converts the current edit head into a visible release Version, and deploys to
   production. It does not depend on a prior preview. On platforms with signed confirmations,
   include `head_commit_sha`, `target`, and the user-approved `confirmation_id`; omit
   `environment_revision_id`. If the platform returns `NEED_SYNC_TO_LATEST` after a confirmation was
   prepared, sync the edit branch, push the new head, re-run validation, call
   `prepare_publish_edit_session` again, and ask `confirm_edit_session_publish` again; an old
   confirmation must not be reused after the head changes or latest production advances. If it
   returns `BUILD_NOT_READY`, poll `get_build_status` for the returned
   `build_id`, then retry with the same idempotency key after the build succeeds. For historical
   visible Versions and rollback flows, continue to use `deploy_site_version` or `rollback_site`.
19. Poll `get_deployment_status` with the returned `deployment_id`
   every 2 seconds for at most 10 minutes. For `outer`, the `deploy_site_version` return value only
   means the request was accepted for security audit; tell the user: "The publish request was
   submitted and is in security review. If it passes, publishing will continue; if it fails, the
   external publish will fail." Report external publish success only after `succeeded`. Treat
   `requested` and `policy_check` as security or publish checks in progress, even when the policy
   check is slow; treat `provisioning`, `health_check`, and `switching` as audit passed and publish
   in progress. On `failed` with `failure.code="SECURITY_REJECTED"`, report that the security audit
   rejected the external publish and no external traffic switch occurred. If a terminal Deployment
   has `failure.code="NEED_SYNC_TO_LATEST"`, do not retry that immutable Deployment and do not stop
   at the error. Read `failure.details.current_deployment_id`, `current_version_id`,
   `current_source_revision_id`, and `latest`. For an edit-session publish, reopen the original edit
   session, obtain fresh edit credentials if needed, call `check_edit_session_sync` to verify the
   current head, then perform the same three-way source sync described in step 8. Resolve
   deterministic conflicts automatically; use `resolve_edit_conflicts` only for uncertain semantic
   conflicts. Revalidate, commit, and push the merged head, prepare and obtain a new signed publish
   confirmation, then call `publish_edit_session` with a new idempotency key and poll the new
   Deployment. Never reuse the failed Deployment, its idempotency key, or its old confirmation. For
   an explicitly requested immutable Version or promotion outside an edit session, re-read the
   current production Version and create a fresh Deployment of the requested Version with a new
   idempotency key. Allow at most three automatic production-advance recoveries in one user action;
   if production keeps advancing, report the current Version and ask the user whether to continue.
   On any other failure, call `get_deployment_logs` with a bounded `limit`, summarize only redacted
   diagnostics, and leave the prior stable route intact.
20. A rollback calls `list_site_versions`, passes the returned summaries to `choose_site_version`,
    and calls `rollback_site` with an explicit reason and a new idempotency key. The Platform
    snapshots the latest Project environment revision at rollback request time; the Deployment
    response may report that selected revision as read-only diagnostic metadata.

Default to `inner`. Do not pass `access_policy_id` when deploying; the platform snapshots the
selected policy onto the Deployment.
## Recovery and idempotency

- Generate one stable idempotency key per logical write and exact payload. If a response is lost or
  times out, retry the same tool with the same key and byte-for-byte equivalent arguments. If the
  head, target, version, schema, access audience, or any other input changes, generate a new key.
- Automatically retry only `TEMPORARY_UNAVAILABLE` and explicit transient network failures, at most
  three times with increasing delay. Deployment/build polling is separate from request retries and
  remains bounded by step 19. Never loop on permission, quota, validation, contract, or security
  failures.
- Poll a Build or Deployment for at most 10 minutes in one invocation. If it is still non-terminal,
  stop waiting cleanly, report its resource ID and current status, and resume through the matching
  status tool on the next invocation. Do not declare failure or create a replacement resource.
- Treat `BUILD_NOT_READY` as progress: poll the returned `build_id`, then repeat the original
  deployment call with the same idempotency key and arguments. Treat `NEED_SYNC_TO_LATEST` as a new
  source state: sync, validate, and push the new head, then prepare a new confirmation and use a new
  publish idempotency key because the payload changed.
- Treat a canceled or declined local form as an intentional pause, not a transient failure. Do not
  reopen it automatically. For correctable form validation, let the interaction tool re-prompt;
  after it returns `status="not_confirmed"`, stop cleanly and explain how the user can retry.
- Never create a replacement Project, edit session, Version, or Deployment merely because the prior
  response was ambiguous. First retry the same idempotent request or use its read/status tool when
  the resource ID is known.

For source-upload tools on contract `3.0`, the submitted `source_sha256` is a diagnostic
expectation. Platform computes the authoritative digest from the received source; a mismatch is
logged and does not block ingestion. Always use the returned `source_revision_id` and
`source_sha256` for subsequent builds and versions, even if the digest differs from the local
manifest. Do not rewrite the local manifest to the returned digest to bypass Executor validation:
local validation still uses the local source algorithm. ZIP integrity, unsafe archives, invalid
contracts/manifests, and build failures remain blocking errors. Platforms advertising baseline `3.0`
apply this policy to all unfinished uploads, including historical ones; there is no per-upload
contract-version selector. The existing Executor local-path call needs no additional arguments.
Successful historical uploads retain their saved revision and digest. A failed or expired upload
retains its terminal result; use a new idempotency key for a new upload after correcting the cause.
For a lost response or an unfinished upload, preserve the original payload and idempotency key.

Legacy `save_source_revision` remains available only for platforms that do not advertise
`source_workflow="platform-project-git"` or compatible edit-session Git workflows. New project
creation, second development sessions, and collaborative edits should use edit sessions and the
platform-managed Project Git repository. The plugin never handles credentials for Platform protected
source/version refs.

## References

- Version model: `references/versioning.md`
- Access control: `references/access-control.md`
- Failure and rollback behavior: `references/deployment-recovery.md`
