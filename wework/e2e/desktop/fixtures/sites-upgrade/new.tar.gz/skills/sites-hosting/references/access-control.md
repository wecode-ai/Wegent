# Access control

For published intranet applications that require login, OpenResty supplies the current user's
email prefix through the `X-SITES-USERNAME` request header. When implementing features that use
this identity, read `../../sites-building/references/authentication.md`. Do not assume this header
is available for anonymous (`audience=all`) access or `outer` publication.

Immediately before an inner production deployment, refresh the Project with `get_site` and use
`inner_access_confirmation_required` as the only decision signal. Do not infer first publication
from `latest_deployment_id`, because that pointer may refer to an outer deployment.

When `inner_access_confirmation_required=false`, keep the current access policy unchanged: do not
call `confirm_inner_site_access` and do not call `update_site_access`. When it is `true`, call
`confirm_inner_site_access` to ask the user to confirm the intranet access audience. If the field is
missing, stop and report an incompatible Platform contract. The form defaults to `all` / “所有人（免登录）”,
and also offers `login` / “登录用户”, `owner` / “仅项目成员”, and `custom` / “指定人”. Project owners
and current collaborators can access every mode. If the user chooses `custom`, the tool asks for
usernames in a second form. Inner `custom` access requires a non-empty comma-separated `subjects`
string containing unique user email prefixes. Inner `all`, `login`, and `owner` access do not accept
`subjects`.

Only after the first inner access confirmation, call `update_site_access` with `target="inner"` and
the selected `audience`; pass `subjects` only for `audience="custom"`. A successful update makes
`inner_access_confirmation_required=false`, including when the deployment that follows later fails.
For outer access updates, omit `audience` and `subjects`; the platform normalizes the stored policy
to `audience=all` and `subjects=[]`. Deployment callers must not pass `access_policy_id`; the
platform selects the latest policy for `project_id + target` and stores an immutable
`access_snapshot_json` on the Deployment.

The platform remains authoritative for permissions, access policy changes, and security review.
Agents may summarize the target, audience, stable URL, and security status to the user.
