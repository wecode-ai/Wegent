import { Buffer } from "node:buffer";
import { spawn } from "node:child_process";
import { access, mkdir, readdir, realpath, rm, stat } from "node:fs/promises";
import path from "node:path";
import readline from "node:readline";

const send = (message) => process.stdout.write(`${JSON.stringify(message)}\n`);
const result = (id, value) => send({ jsonrpc: "2.0", id, result: value });
const error = (id, code, message) => send({ jsonrpc: "2.0", id, error: { code, message } });

class ToolFailure extends Error {
  constructor(code, message) { super(message); this.code = code; }
}

const RESOURCE = "[0-9a-hjkmnp-tv-z]{26}";
const EDIT_SESSION_PATTERN = new RegExp(`^edt_${RESOURCE}$`);
const PROJECT_PATTERN = new RegExp(`^prj_${RESOURCE}$`);
const SOURCE_REF_PATTERN = new RegExp(`^refs/tags/sources/src_${RESOURCE}$`);
const SHA_PATTERN = /^[a-f0-9]{40,64}$/;
const BRANCH_PATTERN = /^edit\/[A-Za-z0-9][A-Za-z0-9._/-]{0,239}$/;
const CREDENTIAL_SCHEMA = {
  type: "object",
  properties: {
    edit_session_id: { type: "string", pattern: `^edt_${RESOURCE}$` },
    project_id: { type: "string", pattern: `^prj_${RESOURCE}$` },
    auth_mode: { const: "http_basic" },
    remote_url: { type: "string", pattern: "^https://" },
    branch: { type: "string", pattern: "^edit/" },
    username: { type: "string", minLength: 1 },
    token: { type: "string", minLength: 1, writeOnly: true },
    token_expires_at: { type: "string", format: "date-time" },
  },
  required: ["edit_session_id", "project_id", "auth_mode", "remote_url", "branch", "username", "token", "token_expires_at"],
  additionalProperties: false,
};

const tools = [
  {
    name: "checkout_edit_session",
    title: "Checkout Edit Session",
    description: "Checkout an edit session with its existing unexpired credential. Do not issue a replacement credential before calling this tool.",
    inputSchema: { type: "object", properties: { destination: { type: "string", minLength: 1 }, credentials: CREDENTIAL_SCHEMA }, required: ["destination", "credentials"], additionalProperties: false },
  },
  {
    name: "fetch_edit_session",
    title: "Fetch Edit Session",
    description: "Fetch only the current edit branch and explicitly supplied platform source refs with an existing unexpired credential.",
    inputSchema: { type: "object", properties: { repository_path: { type: "string", minLength: 1 }, credentials: CREDENTIAL_SCHEMA, source_refs: { type: "array", maxItems: 8, uniqueItems: true, items: { type: "string", pattern: `^refs/tags/sources/src_${RESOURCE}$` } } }, required: ["repository_path", "credentials"], additionalProperties: false },
  },
  {
    name: "push_edit_session",
    title: "Push Edit Session",
    description: "Push clean local HEAD only to the credential's exact edit branch. Force push and caller-defined refspecs are not supported.",
    inputSchema: { type: "object", properties: { repository_path: { type: "string", minLength: 1 }, credentials: CREDENTIAL_SCHEMA, expected_head_sha: { type: "string", pattern: "^[a-f0-9]{40,64}$" } }, required: ["repository_path", "credentials", "expected_head_sha"], additionalProperties: false },
  },
].map((tool) => ({ ...tool, annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: true } }));

function requiredString(value, name) {
  if (typeof value !== "string" || value.trim() === "") throw new ToolFailure("VALIDATION_ERROR", `${name} must be a non-empty string.`);
  return value.trim();
}

function validateCredentials(raw) {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) throw new ToolFailure("VALIDATION_ERROR", "credentials must be an object.");
  const value = {
    editSessionId: requiredString(raw.edit_session_id, "credentials.edit_session_id"),
    projectId: requiredString(raw.project_id, "credentials.project_id"),
    authMode: requiredString(raw.auth_mode, "credentials.auth_mode"),
    remoteUrl: requiredString(raw.remote_url, "credentials.remote_url"),
    branch: requiredString(raw.branch, "credentials.branch"),
    username: requiredString(raw.username, "credentials.username"),
    token: requiredString(raw.token, "credentials.token"),
    tokenExpiresAt: requiredString(raw.token_expires_at, "credentials.token_expires_at"),
  };
  if (!EDIT_SESSION_PATTERN.test(value.editSessionId) || !PROJECT_PATTERN.test(value.projectId)) throw new ToolFailure("VALIDATION_ERROR", "Invalid edit session or project ID.");
  if (value.authMode !== "http_basic") throw new ToolFailure("AUTH_MODE_UNSUPPORTED", "Only http_basic edit credentials are supported.");
  if (!BRANCH_PATTERN.test(value.branch) || value.branch.includes("..") || value.branch.includes("@{") || value.branch.endsWith(".") || value.branch.endsWith("/")) throw new ToolFailure("REF_NOT_ALLOWED", "Only the credential's valid edit branch is allowed.");
  let url;
  try { url = new URL(value.remoteUrl); } catch { throw new ToolFailure("REPOSITORY_NOT_ALLOWED", "The repository URL is invalid."); }
  const allowedHosts = new Set((process.env.WEGENT_EDIT_GIT_ALLOWED_HOSTS ?? "git.intra.weibo.com").split(",").map((item) => item.trim()).filter(Boolean));
  if (url.protocol !== "https:" || url.username || url.password || !allowedHosts.has(url.hostname)) throw new ToolFailure("REPOSITORY_NOT_ALLOWED", "The repository URL or host is not allowed.");
  const repositoryProjectId = `prj-${value.projectId.slice("prj_".length)}`;
  if (!url.pathname.endsWith(`/wegent-sites-${repositoryProjectId}.git`)) throw new ToolFailure("PROJECT_REPOSITORY_MISMATCH", "The repository does not match the credential project.");
  const expiration = Date.parse(value.tokenExpiresAt);
  if (!Number.isFinite(expiration) || expiration <= Date.now() + 60_000) throw new ToolFailure("CREDENTIAL_EXPIRED", "The edit credential is expired or expires within one minute.");
  return value;
}

async function requireRepositoryPath(rawPath) {
  const resolved = await realpath(path.resolve(requiredString(rawPath, "repository_path"))).catch(() => { throw new ToolFailure("PATH_NOT_FOUND", "The repository path does not exist."); });
  if (!(await stat(resolved)).isDirectory()) throw new ToolFailure("PATH_NOT_DIRECTORY", "The repository path must be a directory.");
  await access(path.join(resolved, ".git")).catch(() => { throw new ToolFailure("NOT_A_GIT_REPOSITORY", "The path is not a Git repository."); });
  return resolved;
}

async function checkoutDestination(rawPath) {
  const requested = path.resolve(requiredString(rawPath, "destination"));
  try {
    if (!(await stat(requested)).isDirectory() || (await readdir(requested)).length > 0) throw new ToolFailure("DESTINATION_NOT_EMPTY", "The destination must be an empty directory.");
  } catch (failure) {
    if (failure instanceof ToolFailure) throw failure;
    await mkdir(requested, { recursive: true });
  }
  return requested;
}

function gitEnvironment(credentials) {
  return {
    ...process.env,
    GIT_CONFIG_COUNT: "2",
    GIT_CONFIG_KEY_0: "credential.helper",
    GIT_CONFIG_VALUE_0: "",
    GIT_CONFIG_KEY_1: "http.extraHeader",
    GIT_CONFIG_VALUE_1: `Authorization: Basic ${Buffer.from(`${credentials.username}:${credentials.token}`).toString("base64")}`,
    GIT_TERMINAL_PROMPT: "0",
  };
}

function gitFailure(stderr) {
  const value = stderr.replace(/https?:\/\/[^\s/@]+@/gi, "https://").slice(-2000);
  if (/authentication failed|http basic: access denied|could not read username|401 unauthorized/i.test(value)) return new ToolFailure("GIT_AUTH_FAILED", "Git rejected the attached edit credential.");
  if (/protected branch|not allowed to push|pre-receive hook declined|403 forbidden/i.test(value)) return new ToolFailure("GIT_PERMISSION_DENIED", "Git rejected the requested edit-branch operation.");
  if (/non-fast-forward|fetch first|rejected.*behind/i.test(value)) return new ToolFailure("NON_FAST_FORWARD", "The edit branch advanced and must be synchronized before pushing.");
  return new ToolFailure("GIT_OPERATION_FAILED", value.trim() || "The Git operation failed.");
}

function git(args, cwd, credentials) {
  return new Promise((resolve, reject) => {
    const child = spawn("git", args, { cwd, env: credentials ? gitEnvironment(credentials) : process.env, shell: false, stdio: ["ignore", "pipe", "pipe"] });
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (chunk) => { stdout += chunk; });
    child.stderr.on("data", (chunk) => { stderr += chunk; });
    child.on("error", () => reject(new ToolFailure("GIT_UNAVAILABLE", "Git could not be started.")));
    child.on("close", (code) => code === 0 ? resolve({ stdout, stderr }) : reject(gitFailure(stderr)));
  });
}

async function checkout(args) {
  const credentials = validateCredentials(args.credentials);
  const destination = await checkoutDestination(args.destination);
  try {
    await git(["init", "--quiet", "--initial-branch", credentials.branch], destination);
    await git(["fetch", "--quiet", "--depth=1", "--", credentials.remoteUrl, `refs/heads/${credentials.branch}`], destination, credentials);
    await git(["checkout", "--quiet", "-B", credentials.branch, "FETCH_HEAD"], destination);
    const head = (await git(["rev-parse", "HEAD"], destination)).stdout.trim();
    return { status: "checked_out", edit_session_id: credentials.editSessionId, repository_path: destination, branch: credentials.branch, head_commit_sha: head };
  } catch (failure) {
    await rm(path.join(destination, ".git"), { recursive: true, force: true });
    throw failure;
  }
}

async function fetchEditSession(args) {
  const credentials = validateCredentials(args.credentials);
  const repositoryPath = await requireRepositoryPath(args.repository_path);
  const sourceRefs = args.source_refs ?? [];
  if (!Array.isArray(sourceRefs) || sourceRefs.some((ref) => typeof ref !== "string" || !SOURCE_REF_PATTERN.test(ref))) throw new ToolFailure("REF_NOT_ALLOWED", "Only explicit platform sources/* refs may be fetched.");
  const refspecs = [`+refs/heads/${credentials.branch}:refs/remotes/wegent-edit/${credentials.branch}`, ...sourceRefs.map((ref) => `${ref}:${ref}`)];
  await git(["fetch", "--quiet", "--no-tags", "--", credentials.remoteUrl, ...refspecs], repositoryPath, credentials);
  const remoteHead = (await git(["rev-parse", `refs/remotes/wegent-edit/${credentials.branch}`], repositoryPath)).stdout.trim();
  return { status: "fetched", edit_session_id: credentials.editSessionId, branch: credentials.branch, remote_head_commit_sha: remoteHead, source_refs: sourceRefs };
}

async function push(args) {
  const credentials = validateCredentials(args.credentials);
  const repositoryPath = await requireRepositoryPath(args.repository_path);
  const expectedHead = requiredString(args.expected_head_sha, "expected_head_sha");
  if (!SHA_PATTERN.test(expectedHead)) throw new ToolFailure("VALIDATION_ERROR", "expected_head_sha must be a Git commit SHA.");
  if ((await git(["branch", "--show-current"], repositoryPath)).stdout.trim() !== credentials.branch) throw new ToolFailure("BRANCH_MISMATCH", "The current local branch does not match the edit credential branch.");
  const head = (await git(["rev-parse", "HEAD"], repositoryPath)).stdout.trim();
  if (head !== expectedHead) throw new ToolFailure("HEAD_MISMATCH", "Local HEAD does not match expected_head_sha.");
  if ((await git(["status", "--porcelain"], repositoryPath)).stdout.trim()) throw new ToolFailure("WORKTREE_NOT_CLEAN", "Commit local changes before pushing.");
  await git(["push", "--porcelain", "--", credentials.remoteUrl, `HEAD:refs/heads/${credentials.branch}`], repositoryPath, credentials);
  return { status: "pushed", edit_session_id: credentials.editSessionId, branch: credentials.branch, head_commit_sha: head };
}

async function callTool(id, params) {
  try {
    const args = params.arguments ?? {};
    let value;
    if (params.name === "checkout_edit_session") value = await checkout(args);
    else if (params.name === "fetch_edit_session") value = await fetchEditSession(args);
    else if (params.name === "push_edit_session") value = await push(args);
    else throw new ToolFailure("VALIDATION_ERROR", `Unknown tool: ${params.name}`);
    result(id, { content: [{ type: "text", text: "Wegent edit Git operation completed successfully." }], structuredContent: value });
  } catch (failure) {
    const code = failure instanceof ToolFailure ? failure.code : "INTERNAL_ERROR";
    const message = failure instanceof ToolFailure ? failure.message : "The local edit Git operation failed.";
    result(id, { content: [{ type: "text", text: message }], structuredContent: { error: { code, message } }, isError: true });
  }
}

readline.createInterface({ input: process.stdin, crlfDelay: Infinity }).on("line", (line) => {
  let message;
  try { message = JSON.parse(line); } catch { return; }
  if (message.method === "initialize") {
    result(message.id, { protocolVersion: message.params?.protocolVersion ?? "2025-11-25", capabilities: { tools: {} }, serverInfo: { name: "wegent-sites-edit-git", version: "0.1.0" } });
  } else if (message.method === "notifications/initialized") {
    // Notification: no response.
  } else if (message.method === "ping") result(message.id, {});
  else if (message.method === "tools/list") result(message.id, { tools });
  else if (message.method === "tools/call") void callTool(message.id, message.params ?? {});
  else if (message.id !== undefined) error(message.id, -32601, `Method not found: ${message.method}`);
});
