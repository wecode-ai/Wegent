import { readFile, stat } from "node:fs/promises";
import path from "node:path";
import readline from "node:readline";

const manifest = JSON.parse(await readFile(new URL("../.codex-plugin/plugin.json", import.meta.url), "utf8"));
let nextId = 1;
const pending = new Map();
const send = (message) => process.stdout.write(`${JSON.stringify(message)}\n`);
const result = (id, value) => send({ jsonrpc: "2.0", id, result: value });
const error = (id, code, message) => send({ jsonrpc: "2.0", id, error: { code, message } });
const request = (method, params) => new Promise((resolve, reject) => {
  const id = `wegent-form-${nextId++}`;
  pending.set(id, { resolve, reject });
  send({ jsonrpc: "2.0", id, method, params });
});
const requestForm = (params) => request("elicitation/create", { mode: "form", ...params });
const textResult = (text, structuredContent) => ({ content: [{ type: "text", text }], structuredContent });
const string = (value, name) => {
  if (typeof value !== "string" || value.trim() === "") throw new Error(`${name} must be a non-empty string.`);
  return value.trim();
};
const ACCESS_AUDIENCES = [
  { const: "all", title: "所有人（免登录）" },
  { const: "login", title: "登录用户" },
  { const: "owner", title: "仅项目成员" },
  { const: "custom", title: "指定人" },
];
const ACCESS_AUDIENCE_VALUES = ACCESS_AUDIENCES.map((item) => item.const);
const ACCESS_AUDIENCE_LABELS = ACCESS_AUDIENCES.map((item) => item.title);
const EDIT_SESSION_DEPLOY_ACTIONS = [
  { const: "preview", title: "预览", description: "创建临时预览部署。" },
  { const: "preprod", title: "预发布", description: "覆盖固定预发布环境。" },
  { const: "publish", title: "正式发布", description: "发布到生产环境。" },
];
const DEPLOY_TARGETS = ["inner", "outer"];
const GIT_SHA_PATTERN = /^[a-f0-9]{40,64}$/;
const RESOURCE_ULID_PATTERN = "[0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{26}";
const PROJECT_ULID_PATTERN = RESOURCE_ULID_PATTERN;
const CONFIRMATION_ID_PATTERN = new RegExp(`^cnf_${RESOURCE_ULID_PATTERN}$`);
const EDIT_SESSION_ID_PATTERN = new RegExp(`^edt_${RESOURCE_ULID_PATTERN}$`);
const PROJECT_ID_PATTERN = new RegExp(`^prj_${PROJECT_ULID_PATTERN}$`);
const VERSION_ID_PATTERN = new RegExp(`^ver_${RESOURCE_ULID_PATTERN}$`);

const parseSubjects = (value) => {
  if (typeof value !== "string" || value.trim() === "") throw new Error("subjects must be provided when audience is custom.");
  const subjects = value.split(",").map((item) => item.trim());
  if (subjects.some((item) => item === "")) throw new Error("subjects must be comma-separated usernames without empty entries.");
  for (const subject of subjects) {
    if (!/^[A-Za-z0-9._-]+$/.test(subject)) throw new Error(`Invalid username: ${subject}`);
  }
  if (new Set(subjects).size !== subjects.length) throw new Error("subjects must be unique.");
  return subjects;
};

const optionalGitSha = (value, name) => {
  if (value === undefined || value === null || value === "") return null;
  const sha = string(value, name);
  if (!GIT_SHA_PATTERN.test(sha)) throw new Error(`${name} must be a Git commit SHA.`);
  return sha;
};

const optionalTarget = (value, name) => {
  if (value === undefined || value === null || value === "") return null;
  const target = string(value, name);
  if (!DEPLOY_TARGETS.includes(target)) throw new Error(`${name} must be inner or outer.`);
  return target;
};

const requiredPattern = (value, name, pattern, message) => {
  const normalized = string(value, name);
  if (!pattern.test(normalized)) throw new Error(message);
  return normalized;
};

async function imageOption(option, index) {
  const id = string(option?.id, `options[${index}].id`);
  const title = string(option?.title, `options[${index}].title`);
  const designBrief = string(option?.designBrief, `options[${index}].designBrief`);
  const imagePath = string(option?.imagePath, `options[${index}].imagePath`);
  if (!path.isAbsolute(imagePath)) throw new Error(`options[${index}].imagePath must be absolute.`);
  const fileStat = await stat(imagePath);
  if (!fileStat.isFile() || fileStat.size > 8 * 1024 * 1024) throw new Error("Design images must be regular files no larger than 8 MB.");
  const bytes = await readFile(imagePath);
  let mime;
  if (bytes.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) mime = "image/png";
  else if (bytes[0] === 0xff && bytes[1] === 0xd8) mime = "image/jpeg";
  else if (bytes.subarray(0, 4).toString("ascii") === "RIFF" && bytes.subarray(8, 12).toString("ascii") === "WEBP") mime = "image/webp";
  else throw new Error("Design images must be PNG, JPEG, or WebP.");
  return { id, title, designBrief, image: `data:${mime};base64,${bytes.toString("base64")}` };
}

const tools = [
  {
    name: "choose_site_design", title: "Choose a Wegent Site Design",
    description: "Show exactly three comparable visual directions and return the user's selection.",
    inputSchema: { type: "object", properties: { question: { type: "string", minLength: 1 }, options: { type: "array", minItems: 3, maxItems: 3, items: { type: "object", properties: { id: { type: "string", minLength: 1 }, title: { type: "string", minLength: 1 }, designBrief: { type: "string", minLength: 1 }, imagePath: { type: "string", minLength: 1 } }, required: ["id", "title", "designBrief", "imagePath"], additionalProperties: false } } }, required: ["options"], additionalProperties: false },
  },
  {
    name: "choose_site_version", title: "Choose a Site Version",
    description: "Choose one immutable version from platform-provided version summaries.",
    inputSchema: { type: "object", properties: { question: { type: "string" }, versions: { type: "array", minItems: 1, items: { type: "object", properties: { versionId: { type: "string" }, label: { type: "string" }, summary: { type: "string" } }, required: ["versionId", "label", "summary"], additionalProperties: false } } }, required: ["versions"], additionalProperties: false },
  },
  {
    name: "choose_edit_session_deploy_action", title: "Choose Edit Session Deploy Action",
    description: "Ask whether the current edit-session work should be previewed, deployed to preprod, or formally published.",
    inputSchema: { type: "object", properties: { question: { type: "string" }, headCommitSha: { type: "string", pattern: "^[a-f0-9]{40,64}$" }, target: { enum: DEPLOY_TARGETS } }, additionalProperties: false },
  },
  {
    name: "confirm_inner_site_access", title: "Confirm Inner Site Access",
    description: "Ask for the access audience only when get_site reports inner_access_confirmation_required=true.",
    inputSchema: { type: "object", properties: { question: { type: "string" } }, additionalProperties: false },
  },
  {
    name: "confirm_edit_session_publish", title: "Confirm Edit Session Publish",
    description: "Ask the user to approve a platform-prepared formal publish confirmation.",
    inputSchema: {
      type: "object",
      properties: {
        question: { type: "string" },
        confirmation_id: { type: "string", pattern: `^cnf_${RESOURCE_ULID_PATTERN}$` },
        expires_at: { type: "string", minLength: 1 },
        edit_session_id: { type: "string", pattern: `^edt_${RESOURCE_ULID_PATTERN}$` },
        project_id: { type: "string", pattern: `^prj_${PROJECT_ULID_PATTERN}$` },
        head_commit_sha: { type: "string", pattern: "^[a-f0-9]{40,64}$" },
        target: { enum: DEPLOY_TARGETS },
        latest_version_id: { type: ["string", "null"], pattern: `^ver_${RESOURCE_ULID_PATTERN}$` },
      },
      required: ["confirmation_id", "expires_at", "edit_session_id", "project_id", "head_commit_sha", "target", "latest_version_id"],
      additionalProperties: false,
    },
  },
  {
    name: "resolve_edit_conflicts", title: "Resolve Edit Conflicts",
    description: "Ask the user to choose resolutions for uncertain edit-session merge conflicts.",
    inputSchema: { type: "object", properties: { question: { type: "string" }, conflicts: { type: "array", minItems: 1, maxItems: 12, items: { type: "object", properties: { id: { type: "string", minLength: 1 }, file: { type: "string", minLength: 1 }, summary: { type: "string", minLength: 1 }, options: { type: "array", minItems: 2, maxItems: 4, items: { type: "object", properties: { id: { type: "string", minLength: 1 }, title: { type: "string", minLength: 1 }, description: { type: "string" } }, required: ["id", "title"], additionalProperties: false } } }, required: ["id", "file", "summary", "options"], additionalProperties: false } } }, required: ["conflicts"], additionalProperties: false },
  },
].map((tool) => ({ ...tool, annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: false } }));

async function callTool(id, params) {
  const args = params.arguments ?? {};
  if (params.name === "choose_site_design") {
    if (!Array.isArray(args.options) || args.options.length !== 3) throw new Error("options must contain exactly three items.");
    const options = await Promise.all(args.options.map(imageOption));
    if (new Set(options.map((item) => item.id)).size !== 3) throw new Error("Design option ids must be unique.");
    const response = await requestForm({ message: args.question ?? "请选择站点视觉方向", requestedSchema: { type: "object", properties: { selection: { type: "string", title: "视觉方向", description: "请选择站点视觉方向。", oneOf: options.map(({ id: optionId, title }) => ({ const: optionId, title })) } }, required: ["selection"] } });
    const selected = options.find((item) => item.id === response?.content?.selection);
    if (response?.action !== "accept" || !selected) return result(id, textResult("No design was selected.", { status: "not_selected" }));
    return result(id, textResult(`Selected design: ${selected.title}\n\n${selected.designBrief}`, { status: "selected", ...selected, image: undefined }));
  }
  if (params.name === "choose_site_version") {
    if (!Array.isArray(args.versions) || args.versions.length === 0) throw new Error("versions must not be empty.");
    const ids = args.versions.map((version, index) => string(version.versionId, `versions[${index}].versionId`));
    const response = await requestForm({ message: args.question ?? "请选择要部署或回滚的版本", requestedSchema: { type: "object", properties: { versionId: { type: "string", title: "Version", oneOf: args.versions.map((version, index) => ({ const: ids[index], title: version.label })) } }, required: ["versionId"] } });
    const selected = args.versions.find((version) => version.versionId === response?.content?.versionId);
    if (response?.action !== "accept" || !selected) return result(id, textResult("No version was selected.", { status: "not_selected" }));
    return result(id, textResult(`Selected version: ${selected.label}`, { status: "selected", ...selected }));
  }
  if (params.name === "choose_edit_session_deploy_action") {
    const headCommitSha = optionalGitSha(args.headCommitSha, "headCommitSha");
    const target = optionalTarget(args.target, "target");
    const detail = [
      headCommitSha ? `当前 head: ${headCommitSha}` : null,
      target ? `发布目标: ${target}` : null,
    ].filter(Boolean).join("\n");
    const response = await requestForm({
      message: [args.question ?? "请选择本次编辑的部署动作", detail].filter(Boolean).join("\n\n"),
      requestedSchema: {
        type: "object",
        properties: {
          action: {
            type: "string",
            title: "部署动作",
            description: "请选择预览、预发布或正式发布。",
            default: "preview",
            oneOf: EDIT_SESSION_DEPLOY_ACTIONS,
          },
        },
        required: ["action"],
      },
    });
    const action = response?.content?.action;
    if (response?.action !== "accept" || !EDIT_SESSION_DEPLOY_ACTIONS.some((item) => item.const === action)) {
      return result(id, textResult("No edit-session deploy action was selected.", { status: "not_selected", elicitationAction: response?.action ?? null, elicitationContent: response?.content ?? null }));
    }
    const selected = EDIT_SESSION_DEPLOY_ACTIONS.find((item) => item.const === action);
    return result(id, textResult(`Selected edit-session deploy action: ${selected.title}`, { status: "selected", action }));
  }
  if (params.name === "confirm_inner_site_access") {
    const audienceResponse = await requestForm({
      message: args.question ?? "请确认内网站点访问范围",
      requestedSchema: {
        type: "object",
        properties: {
          audience: {
            type: "string",
            title: "访问范围",
            description: "请选择站点发布到内网后的访问范围。",
            default: "all",
            enum: ACCESS_AUDIENCE_VALUES,
            enumNames: ACCESS_AUDIENCE_LABELS,
          },
        },
        required: ["audience"],
      },
    });
    const audience = audienceResponse?.content?.audience;
    if (audienceResponse?.action !== "accept" || !ACCESS_AUDIENCES.some((item) => item.const === audience)) {
      return result(id, textResult("Inner site access was not confirmed.", { status: "not_confirmed", elicitationAction: audienceResponse?.action ?? null, elicitationContent: audienceResponse?.content ?? null }));
    }
    if (audience === "custom") {
      let validationMessage = null;
      for (let attempt = 1; attempt <= 3; attempt += 1) {
        const subjectsResponse = await requestForm({
          message: ["请输入允许访问内网站点的用户名", validationMessage].filter(Boolean).join("\n\n"),
          requestedSchema: {
            type: "object",
            properties: {
              subjects: {
                type: "string",
                title: "指定用户名",
                description: "请输入多个用户名，使用英文逗号分割。",
                maxLength: 8192,
              },
            },
            required: ["subjects"],
          },
        });
        if (subjectsResponse?.action !== "accept") {
          return result(id, textResult("Inner site access subjects were not confirmed.", { status: "not_confirmed", elicitationAction: subjectsResponse?.action ?? null, elicitationContent: subjectsResponse?.content ?? null }));
        }
        try {
          const subjects = parseSubjects(subjectsResponse?.content?.subjects);
          const subjectsText = subjects.join(",");
          return result(id, textResult(`Selected inner access: 指定人 (${subjectsText})`, { status: "confirmed", target: "inner", audience, subjects: subjectsText, subjectList: subjects }));
        } catch (validationError) {
          validationMessage = `输入格式不正确：${validationError instanceof Error ? validationError.message : "请使用英文逗号分割用户名。"}`;
        }
      }
      return result(id, textResult("Inner site access subjects remained invalid after three attempts.", { status: "not_confirmed", reason: "invalid_subjects" }));
    }
    const label = ACCESS_AUDIENCES.find((item) => item.const === audience).title;
    return result(id, textResult(`Selected inner access: ${label}`, { status: "confirmed", target: "inner", audience }));
  }
  if (params.name === "confirm_edit_session_publish") {
    const confirmationId = requiredPattern(args.confirmation_id, "confirmation_id", CONFIRMATION_ID_PATTERN, "confirmation_id must be a publish confirmation id.");
    const editSessionId = requiredPattern(args.edit_session_id, "edit_session_id", EDIT_SESSION_ID_PATTERN, "edit_session_id must be an edit session id.");
    const projectId = requiredPattern(args.project_id, "project_id", PROJECT_ID_PATTERN, "project_id must be a project id.");
    const headCommitSha = requiredPattern(args.head_commit_sha, "head_commit_sha", GIT_SHA_PATTERN, "head_commit_sha must be a Git commit SHA.");
    const target = optionalTarget(args.target, "target");
    if (!target) throw new Error("target must be inner or outer.");
    const expiresAt = string(args.expires_at, "expires_at");
    if (!Object.prototype.hasOwnProperty.call(args, "latest_version_id")) throw new Error("latest_version_id must be provided.");
    const latestVersionId = args.latest_version_id === null ? null : requiredPattern(args.latest_version_id, "latest_version_id", VERSION_ID_PATTERN, "latest_version_id must be a version id.");
    const detail = [
      `项目: ${projectId}`,
      `编辑: ${editSessionId}`,
      `提交: ${headCommitSha}`,
      `目标: ${target}`,
      latestVersionId ? `当前正式版本: ${latestVersionId}` : "当前正式版本: 无",
      `确认有效期至: ${expiresAt}`,
    ].join("\n");
    const response = await requestForm({
      message: [args.question ?? "请确认是否正式发布当前编辑结果", detail].filter(Boolean).join("\n\n"),
      requestedSchema: {
        type: "object",
        properties: {
          decision: {
            type: "string",
            title: "正式发布",
            description: "确认后将使用平台生成的短期确认 ID 发布到生产环境。",
            oneOf: [
              { const: "confirm", title: "确认发布" },
              { const: "cancel", title: "暂不发布" },
            ],
          },
        },
        required: ["decision"],
      },
    });
    if (response?.action !== "accept" || response?.content?.decision !== "confirm") {
      return result(id, textResult("Formal publish was not confirmed.", {
        status: "not_confirmed",
        confirmation_id: confirmationId,
        elicitationAction: response?.action ?? null,
        elicitationContent: response?.content ?? null,
      }));
    }
    return result(id, textResult("Formal publish confirmed.", {
      status: "confirmed",
      confirmation_id: confirmationId,
      expires_at: expiresAt,
      summary: {
        edit_session_id: editSessionId,
        project_id: projectId,
        head_commit_sha: headCommitSha,
        target,
        latest_version_id: latestVersionId,
      },
    }));
  }
  if (params.name === "resolve_edit_conflicts") {
    if (!Array.isArray(args.conflicts) || args.conflicts.length === 0) throw new Error("conflicts must not be empty.");
    const properties = {};
    const required = [];
    const normalized = args.conflicts.map((conflict, index) => {
      const conflictId = string(conflict?.id, `conflicts[${index}].id`);
      const file = string(conflict?.file, `conflicts[${index}].file`);
      const summary = string(conflict?.summary, `conflicts[${index}].summary`);
      if (!Array.isArray(conflict?.options) || conflict.options.length < 2 || conflict.options.length > 4) {
        throw new Error(`conflicts[${index}].options must contain 2 to 4 items.`);
      }
      const options = conflict.options.map((option, optionIndex) => ({
        id: string(option?.id, `conflicts[${index}].options[${optionIndex}].id`),
        title: string(option?.title, `conflicts[${index}].options[${optionIndex}].title`),
        description: typeof option?.description === "string" ? option.description : "",
      }));
      if (new Set(options.map((option) => option.id)).size !== options.length) throw new Error(`conflicts[${index}].options ids must be unique.`);
      properties[conflictId] = {
        type: "string",
        title: file,
        description: summary,
        oneOf: options.map((option) => ({ const: option.id, title: option.title, description: option.description })),
      };
      required.push(conflictId);
      return { id: conflictId, file, summary, options };
    });
    const response = await requestForm({ message: args.question ?? "请选择冲突处理方式", requestedSchema: { type: "object", properties, required } });
    if (response?.action !== "accept") return result(id, textResult("Edit conflicts were not resolved.", { status: "not_confirmed", conflicts: normalized }));
    const resolutions = Object.fromEntries(normalized.map((conflict) => [conflict.id, response.content?.[conflict.id] ?? null]));
    if (Object.values(resolutions).some((value) => typeof value !== "string")) throw new Error("All conflicts must be resolved.");
    return result(id, textResult("Edit conflict resolutions confirmed.", { status: "confirmed", resolutions, conflicts: normalized }));
  }
  throw new Error(`Unknown tool: ${params.name ?? ""}`);
}

async function handle(message) {
  if (message.id !== undefined && pending.has(message.id) && (message.result !== undefined || message.error !== undefined)) {
    const waiter = pending.get(message.id); pending.delete(message.id);
    message.error ? waiter.reject(new Error(message.error.message)) : waiter.resolve(message.result); return;
  }
  const { id, method, params } = message;
  if (method === "initialize") {
    return result(id, { protocolVersion: params?.protocolVersion ?? "2025-11-25", capabilities: { tools: {} }, serverInfo: { name: "Wegent Sites Interactions", version: manifest.version } });
  }
  if (method === "ping") return result(id, {});
  if (method === "tools/list") return result(id, { tools });
  if (method === "tools/call") { try { return await callTool(id, params); } catch (cause) { return error(id, -32602, cause instanceof Error ? cause.message : String(cause)); } }
  if (id !== undefined) error(id, -32601, `Method not found: ${method}`);
}

const lines = readline.createInterface({ input: process.stdin, crlfDelay: Infinity });
lines.on("line", (line) => { if (line.trim()) { try { void handle(JSON.parse(line)); } catch { error(null, -32700, "Parse error"); } } });
