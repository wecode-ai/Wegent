import { readFile, stat } from "node:fs/promises";
import path from "node:path";
import readline from "node:readline";

const manifest = JSON.parse(await readFile(new URL("../.codex-plugin/plugin.json", import.meta.url), "utf8"));
let nextId = 1;
const pending = new Map();
const send = (message) => process.stdout.write(`${JSON.stringify(message)}\n`);
const result = (id, value) => send({ jsonrpc: "2.0", id, result: value });
const error = (id, code, message) => send({ jsonrpc: "2.0", id, error: { code, message } });
const request = (method, params) => new Promise((resolve, reject) => {
  const id = `wegent-form-${nextId++}`;
  pending.set(id, { resolve, reject });
  send({ jsonrpc: "2.0", id, method, params });
});
const requestForm = (params) => request("elicitation/create", { mode: "form", ...params });
const textResult = (text, structuredContent) => ({ content: [{ type: "text", text }], structuredContent });
const string = (value, name) => {
  if (typeof value !== "string" || value.trim() === "") throw new Error(`${name} must be a non-empty string.`);
  return value.trim();
};
const ACCESS_AUDIENCES = [
  { const: "all", title: "所有人" },
  { const: "owner", title: "仅自己" },
  { const: "custom", title: "指定人" },
];
const ACCESS_AUDIENCE_VALUES = ACCESS_AUDIENCES.map((item) => item.const);
const ACCESS_AUDIENCE_LABELS = ACCESS_AUDIENCES.map((item) => item.title);

const parseSubjects = (value) => {
  if (typeof value !== "string" || value.trim() === "") throw new Error("subjects must be provided when audience is custom.");
  const subjects = value.split(",").map((item) => item.trim());
  if (subjects.some((item) => item === "")) throw new Error("subjects must be comma-separated usernames without empty entries.");
  for (const subject of subjects) {
    if (!/^[A-Za-z0-9._-]+$/.test(subject)) throw new Error(`Invalid username: ${subject}`);
  }
  if (new Set(subjects).size !== subjects.length) throw new Error("subjects must be unique.");
  return subjects;
};

async function imageOption(option, index) {
  const id = string(option?.id, `options[${index}].id`);
  const title = string(option?.title, `options[${index}].title`);
  const designBrief = string(option?.designBrief, `options[${index}].designBrief`);
  const imagePath = string(option?.imagePath, `options[${index}].imagePath`);
  if (!path.isAbsolute(imagePath)) throw new Error(`options[${index}].imagePath must be absolute.`);
  const fileStat = await stat(imagePath);
  if (!fileStat.isFile() || fileStat.size > 8 * 1024 * 1024) throw new Error("Design images must be regular files no larger than 8 MB.");
  const bytes = await readFile(imagePath);
  let mime;
  if (bytes.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) mime = "image/png";
  else if (bytes[0] === 0xff && bytes[1] === 0xd8) mime = "image/jpeg";
  else if (bytes.subarray(0, 4).toString("ascii") === "RIFF" && bytes.subarray(8, 12).toString("ascii") === "WEBP") mime = "image/webp";
  else throw new Error("Design images must be PNG, JPEG, or WebP.");
  return { id, title, designBrief, image: `data:${mime};base64,${bytes.toString("base64")}` };
}

const tools = [
  {
    name: "choose_site_design", title: "Choose a Wegent Site Design",
    description: "Show exactly three comparable visual directions and return the user's selection.",
    inputSchema: { type: "object", properties: { question: { type: "string", minLength: 1 }, options: { type: "array", minItems: 3, maxItems: 3, items: { type: "object", properties: { id: { type: "string", minLength: 1 }, title: { type: "string", minLength: 1 }, designBrief: { type: "string", minLength: 1 }, imagePath: { type: "string", minLength: 1 } }, required: ["id", "title", "designBrief", "imagePath"], additionalProperties: false } } }, required: ["options"], additionalProperties: false },
  },
  {
    name: "choose_site_version", title: "Choose a Site Version",
    description: "Choose one immutable version from platform-provided version summaries.",
    inputSchema: { type: "object", properties: { question: { type: "string" }, versions: { type: "array", minItems: 1, items: { type: "object", properties: { versionId: { type: "string" }, label: { type: "string" }, summary: { type: "string" } }, required: ["versionId", "label", "summary"], additionalProperties: false } } }, required: ["versions"], additionalProperties: false },
  },
  {
    name: "confirm_inner_site_access", title: "Confirm Inner Site Access",
    description: "Ask the user to confirm the access audience before publishing a site to the intranet.",
    inputSchema: { type: "object", properties: { question: { type: "string" } }, additionalProperties: false },
  },
].map((tool) => ({ ...tool, annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: false } }));

async function callTool(id, params) {
  const args = params.arguments ?? {};
  if (params.name === "choose_site_design") {
    if (!Array.isArray(args.options) || args.options.length !== 3) throw new Error("options must contain exactly three items.");
    const options = await Promise.all(args.options.map(imageOption));
    if (new Set(options.map((item) => item.id)).size !== 3) throw new Error("Design option ids must be unique.");
    const response = await requestForm({ message: args.question ?? "请选择站点视觉方向", requestedSchema: { type: "object", properties: { selection: { type: "string", title: "视觉方向", description: "请选择站点视觉方向。", oneOf: options.map(({ id: optionId, title }) => ({ const: optionId, title })) } }, required: ["selection"] } });
    const selected = options.find((item) => item.id === response?.content?.selection);
    if (response?.action !== "accept" || !selected) return result(id, textResult("No design was selected.", { status: "not_selected" }));
    return result(id, textResult(`Selected design: ${selected.title}\n\n${selected.designBrief}`, { status: "selected", ...selected, image: undefined }));
  }
  if (params.name === "choose_site_version") {
    if (!Array.isArray(args.versions) || args.versions.length === 0) throw new Error("versions must not be empty.");
    const ids = args.versions.map((version, index) => string(version.versionId, `versions[${index}].versionId`));
    const response = await requestForm({ message: args.question ?? "请选择要部署或回滚的版本", requestedSchema: { type: "object", properties: { versionId: { type: "string", title: "Version", oneOf: args.versions.map((version, index) => ({ const: ids[index], title: version.label })) } }, required: ["versionId"] } });
    const selected = args.versions.find((version) => version.versionId === response?.content?.versionId);
    if (response?.action !== "accept" || !selected) return result(id, textResult("No version was selected.", { status: "not_selected" }));
    return result(id, textResult(`Selected version: ${selected.label}`, { status: "selected", ...selected }));
  }
  if (params.name === "confirm_inner_site_access") {
    const audienceResponse = await requestForm({
      message: args.question ?? "请确认内网站点访问范围",
      requestedSchema: {
        type: "object",
        properties: {
          audience: {
            type: "string",
            title: "访问范围",
            description: "请选择站点发布到内网后的访问范围。",
            enum: ACCESS_AUDIENCE_VALUES,
            enumNames: ACCESS_AUDIENCE_LABELS,
          },
        },
        required: ["audience"],
      },
    });
    const audience = audienceResponse?.content?.audience;
    if (audienceResponse?.action !== "accept" || !ACCESS_AUDIENCES.some((item) => item.const === audience)) {
      return result(id, textResult("Inner site access was not confirmed.", { status: "not_confirmed", elicitationAction: audienceResponse?.action ?? null, elicitationContent: audienceResponse?.content ?? null }));
    }
    if (audience === "custom") {
      const subjectsResponse = await requestForm({
        message: "请输入允许访问内网站点的用户名",
        requestedSchema: {
          type: "object",
          properties: {
            subjects: {
              type: "string",
              title: "指定用户名",
              description: "请输入多个用户名，使用英文逗号分割。",
            },
          },
          required: ["subjects"],
        },
      });
      if (subjectsResponse?.action !== "accept") {
        return result(id, textResult("Inner site access subjects were not confirmed.", { status: "not_confirmed", elicitationAction: subjectsResponse?.action ?? null, elicitationContent: subjectsResponse?.content ?? null }));
      }
      const subjects = parseSubjects(subjectsResponse?.content?.subjects);
      const subjectsText = subjects.join(",");
      return result(id, textResult(`Selected inner access: 指定人 (${subjectsText})`, { status: "confirmed", target: "inner", audience, subjects: subjectsText, subjectList: subjects }));
    }
    const label = ACCESS_AUDIENCES.find((item) => item.const === audience).title;
    return result(id, textResult(`Selected inner access: ${label}`, { status: "confirmed", target: "inner", audience, subjects: null }));
  }
  throw new Error(`Unknown tool: ${params.name ?? ""}`);
}

async function handle(message) {
  if (message.id !== undefined && pending.has(message.id) && (message.result !== undefined || message.error !== undefined)) {
    const waiter = pending.get(message.id); pending.delete(message.id);
    message.error ? waiter.reject(new Error(message.error.message)) : waiter.resolve(message.result); return;
  }
  const { id, method, params } = message;
  if (method === "initialize") {
    return result(id, { protocolVersion: params?.protocolVersion ?? "2025-11-25", capabilities: { tools: {} }, serverInfo: { name: "Wegent Sites Interactions", version: manifest.version } });
  }
  if (method === "ping") return result(id, {});
  if (method === "tools/list") return result(id, { tools });
  if (method === "tools/call") { try { return await callTool(id, params); } catch (cause) { return error(id, -32602, cause instanceof Error ? cause.message : String(cause)); } }
  if (id !== undefined) error(id, -32601, `Method not found: ${method}`);
}

const lines = readline.createInterface({ input: process.stdin, crlfDelay: Infinity });
lines.on("line", (line) => { if (line.trim()) { try { void handle(JSON.parse(line)); } catch { error(null, -32700, "Parse error"); } } });
