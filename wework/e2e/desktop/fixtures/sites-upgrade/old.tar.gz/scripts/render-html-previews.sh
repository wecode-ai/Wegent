#!/usr/bin/env bash
set -euo pipefail
echo "Phase 0 does not bundle a browser renderer. Open the project with the in-app browser and capture 375px and 1440px previews." >&2
exit 2
