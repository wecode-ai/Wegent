# Static runtimes

## HTML

Provide an accessible `index.html` and keep every local asset reference valid. Use native CSS and
JavaScript unless a framework adds real value. Static navigation must work without a server-side
router.

## React/Vite

Phase 0 templates use npm and a committed `package-lock.json`. Provide a `build` script and a
deterministic `dist` output. Browser requests to backend APIs use relative `/api` URLs. Do not use
CDN-loaded build dependencies.
