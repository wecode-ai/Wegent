# Page quality

Build the first screen around the user's actual task. Use semantic landmarks, a clear heading
hierarchy, visible keyboard focus, 44px touch targets, responsive layout without horizontal
scrolling, reduced-motion support, useful loading/empty/error states, and meaningful metadata.
Prefer system or self-hosted fonts. Use consistent spacing and color tokens. Avoid lorem ipsum,
generic feature labels, decorative imagery without purpose, and hand-written placeholder SVGs.

Run the deterministic page-quality checker, then visually smoke-test complex pages at 375px and
1440px. Mechanical checks supplement rather than replace visual judgment.
