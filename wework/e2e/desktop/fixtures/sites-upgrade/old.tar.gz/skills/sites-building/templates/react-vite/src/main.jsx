import React from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

function App() {
  return (
    <main className="shell">
      <p className="eyebrow">React starter</p>
      <h1>从真实任务开始构建</h1>
      <p>请替换为产品相关内容，并在交付前删除 starter 痕迹。</p>
      <button type="button">开始</button>
    </main>
  );
}

createRoot(document.getElementById("root")).render(<App />);
