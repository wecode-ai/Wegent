# Persistence

FastAPI and React plus FastAPI projects may use the platform MySQL capability for durable storage.
Static-only HTML and React Vite sites do not connect directly to MySQL. PostgreSQL and arbitrary
external databases are not provisioned by Wegent Sites; declare those connections in `required_env`
only when the user explicitly supplies an external service.

Enable MySQL by adding `capabilities.mysql.enabled=true` to `.wegent/hosting.json` and, for table
schema management, `capabilities.mysql.schema_file` pointing to a safe project-relative JSON file
such as `.wegent/mysql/schema.json`. The schema file uses logical table, column, and index names.
The platform validates it, maps logical table names to physical names, applies safe DDL through MCP,
and records migration audit history.

Runtime code reads only these injected environment variables:

```text
WEGENT_MYSQL_HOST
WEGENT_MYSQL_PORT
WEGENT_MYSQL_USER
WEGENT_MYSQL_PASSWORD
WEGENT_MYSQL_DATABASE
WEGENT_MYSQL_TABLE_PREFIX
```

Do not put these names in `required_env`; they are reserved platform variables. Never commit
credential values, host-specific constants, or example passwords. Do not print connection settings
or include them in logs, prompts, screenshots, or API responses.

Runtime code must build table names as `WEGENT_MYSQL_TABLE_PREFIX + logical_table_name` after
validating that the logical table name is a hard-coded, schema-declared identifier. Do not construct
physical names in source code, accept table names from users, or perform DDL at runtime. The first
release uses a shared runtime MySQL account, so MySQL itself does not enforce project-level table
isolation; treat the platform-managed prefix and schema tools as required guardrails.

SQLite may be used only for disposable demos. Dynamic deployments use delete-then-create behavior
and do not guarantee SQLite durability.
