import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

function App() {
  const [summary, setSummary] = useState("正在载入…");

  useEffect(() => {
    fetch("/api/summary")
      .then((response) => {
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        return response.json();
      })
      .then((data) => setSummary(data.summary))
      .catch(() => setSummary("暂时无法获取数据。"));
  }, []);

  return (
    <main className="shell">
      <p className="eyebrow">Full-stack starter</p>
      <h1>前后端链路已就绪</h1>
      <p role="status">{summary}</p>
    </main>
  );
}

createRoot(document.getElementById("root")).render(<App />);
