import os
import re

from fastapi import FastAPI

app = FastAPI(title="Wegent Site API", version="0.1.0")

MYSQL_LOGICAL_TABLE = re.compile(r"^(?!p_)[a-z][a-z0-9_]{0,47}$")
MYSQL_ENV_KEYS = (
    "WEGENT_MYSQL_HOST",
    "WEGENT_MYSQL_PORT",
    "WEGENT_MYSQL_USER",
    "WEGENT_MYSQL_PASSWORD",
    "WEGENT_MYSQL_DATABASE",
    "WEGENT_MYSQL_TABLE_PREFIX",
)


def mysql_runtime_env() -> dict[str, str] | None:
    values = {key: os.environ.get(key) for key in MYSQL_ENV_KEYS}
    present = {key: value for key, value in values.items() if value}
    if not present:
        return None
    missing = sorted(set(MYSQL_ENV_KEYS) - set(present))
    if missing:
        raise RuntimeError(f"incomplete Wegent MySQL runtime environment: {', '.join(missing)}")
    return {key: value for key, value in present.items()}


def mysql_table_name(logical_table: str) -> str:
    if not MYSQL_LOGICAL_TABLE.fullmatch(logical_table):
        raise ValueError("invalid logical MySQL table name")
    settings = mysql_runtime_env()
    if settings is None:
        raise RuntimeError("Wegent MySQL runtime environment is not available")
    return settings["WEGENT_MYSQL_TABLE_PREFIX"] + logical_table


@app.get("/health", tags=["platform"])
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/api/hello", tags=["example"])
def hello() -> dict[str, str]:
    return {"message": "Replace this endpoint with product behavior."}
