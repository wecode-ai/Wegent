const action = document.querySelector("#primary-action");
const status = document.querySelector("#status");

action?.addEventListener("click", () => {
  status.textContent = "Starter is working. Replace this interaction with the product behavior.";
});
