# React plus FastAPI runtime

Keep `frontend/` and `backend/` independently understandable. Build the frontend to
`frontend/dist`. In the platform image, Nginx serves the built files and proxies `/api/*` and
`/health` to FastAPI. SPA fallback applies only to non-API routes. Phase 0 models this as one image;
do not introduce multi-service orchestration.

When durable storage is required, put MySQL access behind FastAPI routes. Browser code continues to
use relative `/api` paths and never receives MySQL connection variables or physical table prefixes.
Keep `/health` database-independent.
