# FastAPI runtime

The default entrypoint is `backend.main:app`. The application must expose unauthenticated
`GET /health` returning a successful status for runtime health checks. Bind to `0.0.0.0`; read the
port from the platform at runtime. Pin dependencies in `requirements.txt`. Read databases and
third-party credentials from environment variables and never print their values.

For MySQL, use only the `WEGENT_MYSQL_*` runtime variables injected by the platform. Keep `/health`
independent from MySQL because local validation and build-time health checks may run without those
variables. Add a MySQL driver dependency only when the application actually opens a connection, and
use a small helper to validate logical table names before combining them with
`WEGENT_MYSQL_TABLE_PREFIX`.
