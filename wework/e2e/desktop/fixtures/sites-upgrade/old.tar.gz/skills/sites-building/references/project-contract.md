# Project contract

`.wegent/hosting.json` uses `contracts/project-contract.schema.json`. Standard templates need only
`schema_version`, `project_id`, `runtime_profile`, and `required_env`. Use `overrides` only to remove
real ambiguity in an adopted project. Never place shell commands, Docker flags, credentials, host
paths, or arbitrary capabilities in the contract.

The only first-release project capability is `capabilities.mysql`, valid for `fastapi` and
`react-fastapi` projects. Declare it only when durable MySQL storage is required. If
`schema_file` is present, it must be a safe project-relative path and should usually be
`.wegent/mysql/schema.json`.

`validate-project.py` creates `.wegent/build-manifest.json`. The manifest is generated evidence,
not a user-maintained build script. The platform must re-detect source and reject disagreement with
`CONTRACT_INCOMPATIBLE` rather than trusting the client manifest.
