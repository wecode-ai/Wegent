#!/usr/bin/env python3
"""Validate a supported project and generate its build manifest."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import py_compile
import re
import subprocess
import sys
from pathlib import Path

_DETECT_PATH = Path(__file__).with_name("detect-project.py")
_SPEC = importlib.util.spec_from_file_location("wegent_sites_detect", _DETECT_PATH)
if _SPEC is None or _SPEC.loader is None:
    raise RuntimeError(f"cannot load detector: {_DETECT_PATH}")
_DETECT_MODULE = importlib.util.module_from_spec(_SPEC)
_SPEC.loader.exec_module(_DETECT_MODULE)
detect = _DETECT_MODULE.detect
load_json = _DETECT_MODULE.load_json

VERSION = "0.1.0"
EXCLUDED = {".git", "node_modules", "dist", "__pycache__", ".pytest_cache", ".DS_Store"}
PROJECT_ID = re.compile(r"^prj_[0-9a-hjkmnp-tv-z]{26}$")
ENV_KEY = re.compile(r"^[A-Z][A-Z0-9_]{0,127}$")
PYTHON_ENTRYPOINT = re.compile(r"^[A-Za-z_][A-Za-z0-9_.]*:[A-Za-z_][A-Za-z0-9_]*$")
MYSQL_IDENTIFIER = re.compile(r"^[a-z][a-z0-9_]{0,47}$")
MYSQL_DECIMAL = re.compile(r"^DECIMAL\(([1-9][0-9]?),([0-9]{1,2})\)$")
MYSQL_VARCHAR = re.compile(r"^VARCHAR\(([1-9][0-9]{0,3})\)$")
MYSQL_EXACT_TYPES = {"BIGINT", "INT", "TINYINT(1)", "TEXT", "MEDIUMTEXT", "DATETIME", "DATETIME(6)", "DATE", "JSON"}
MYSQL_INTEGER_TYPES = {"BIGINT", "INT"}
RESERVED_MYSQL_ENV_KEYS = {
    "WEGENT_MYSQL_HOST",
    "WEGENT_MYSQL_PORT",
    "WEGENT_MYSQL_USER",
    "WEGENT_MYSQL_PASSWORD",
    "WEGENT_MYSQL_DATABASE",
    "WEGENT_MYSQL_TABLE_PREFIX",
}


def source_digest(root: Path) -> str:
    digest = hashlib.sha256()
    for path in sorted(p for p in root.rglob("*") if p.is_file()):
        rel = path.relative_to(root)
        if any(part in EXCLUDED for part in rel.parts) or rel.as_posix() == ".wegent/build-manifest.json":
            continue
        digest.update(rel.as_posix().encode())
        digest.update(b"\0")
        digest.update(path.read_bytes())
        digest.update(b"\0")
    return f"sha256:{digest.hexdigest()}"


def add_check(checks: list[dict], name: str, passed: bool, detail: str) -> None:
    checks.append({"name": name, "passed": passed, "detail": detail})


def valid_relative_path(value: object) -> bool:
    if not isinstance(value, str) or not 1 <= len(value) <= 512 or "\x00" in value:
        return False
    path = Path(value)
    return not path.is_absolute() and ".." not in path.parts


def valid_mysql_type(value: object) -> bool:
    if not isinstance(value, str):
        return False
    value = value.upper()
    if value in MYSQL_EXACT_TYPES:
        return True
    decimal = MYSQL_DECIMAL.fullmatch(value)
    if decimal:
        precision, scale = int(decimal.group(1)), int(decimal.group(2))
        return 1 <= precision <= 99 and 0 <= scale <= 30
    varchar = MYSQL_VARCHAR.fullmatch(value)
    if varchar:
        return 1 <= int(varchar.group(1)) <= 9999
    return False


def validate_mysql_schema(schema: object) -> list[str]:
    problems: list[str] = []
    if not isinstance(schema, dict):
        return ["MySQL schema must be a JSON object."]
    allowed_schema = {"schema_version", "tables"}
    unknown_schema = sorted(set(schema) - allowed_schema)
    if unknown_schema:
        problems.append(f"MySQL schema has unknown fields: {', '.join(unknown_schema)}.")
    if schema.get("schema_version") != "1.0":
        problems.append("MySQL schema_version must be 1.0.")
    tables = schema.get("tables")
    if not isinstance(tables, list) or len(tables) > 32:
        problems.append("MySQL schema tables must be an array with at most 32 entries.")
        return problems
    table_names: set[str] = set()
    for table_index, table in enumerate(tables):
        location = f"MySQL schema tables[{table_index}]"
        if not isinstance(table, dict):
            problems.append(f"{location} must be an object.")
            continue
        allowed_table = {"name", "columns", "primary_key", "indexes"}
        unknown_table = sorted(set(table) - allowed_table)
        if unknown_table:
            problems.append(f"{location} has unknown fields: {', '.join(unknown_table)}.")
        table_name = table.get("name")
        if not isinstance(table_name, str) or not MYSQL_IDENTIFIER.fullmatch(table_name):
            problems.append(f"{location}.name must be a valid logical table name.")
        elif table_name.startswith("p_"):
            problems.append(f"{location}.name must not use the reserved p_ prefix.")
        elif table_name in table_names:
            problems.append(f"MySQL schema table name is duplicated: {table_name}.")
        else:
            table_names.add(table_name)

        columns = table.get("columns")
        if not isinstance(columns, list) or not 1 <= len(columns) <= 64:
            problems.append(f"{location}.columns must be an array with 1 to 64 entries.")
            continue
        column_names: set[str] = set()
        column_types: dict[str, str] = {}
        auto_increment_columns: set[str] = set()
        for column_index, column in enumerate(columns):
            column_location = f"{location}.columns[{column_index}]"
            if not isinstance(column, dict):
                problems.append(f"{column_location} must be an object.")
                continue
            allowed_column = {"name", "type", "nullable", "auto_increment", "default"}
            unknown_column = sorted(set(column) - allowed_column)
            if unknown_column:
                problems.append(f"{column_location} has unknown fields: {', '.join(unknown_column)}.")
            column_name = column.get("name")
            if not isinstance(column_name, str) or not MYSQL_IDENTIFIER.fullmatch(column_name):
                problems.append(f"{column_location}.name must be a valid logical column name.")
            elif column_name in column_names:
                problems.append(f"MySQL schema column name is duplicated in {table_name}: {column_name}.")
            else:
                column_names.add(column_name)
            column_type = column.get("type")
            if not valid_mysql_type(column_type):
                problems.append(f"{column_location}.type is not supported in the first MySQL release.")
            elif isinstance(column_name, str):
                column_types[column_name] = column_type.upper()
            if not isinstance(column.get("nullable"), bool):
                problems.append(f"{column_location}.nullable must be boolean.")
            auto_increment = column.get("auto_increment")
            if auto_increment is not None and auto_increment is not True:
                problems.append(f"{column_location}.auto_increment must be true when present.")
            elif auto_increment and isinstance(column_name, str):
                auto_increment_columns.add(column_name)
            default = column.get("default")
            if "default" in column:
                if default is not None and not isinstance(default, (str, int, float, bool)):
                    problems.append(f"{column_location}.default must be string, number, boolean, or null.")
                elif isinstance(default, str):
                    if len(default) > 1024:
                        problems.append(f"{column_location}.default must be at most 1024 characters.")
                    elif "\x00" in default or ";" in default:
                        problems.append(f"{column_location}.default contains unsupported characters.")

        primary_key = table.get("primary_key")
        if primary_key is None:
            primary_key_names: set[str] = set()
        elif not isinstance(primary_key, list) or not primary_key:
            problems.append(f"{location}.primary_key must be a non-empty array when present.")
            primary_key_names = set()
        else:
            primary_key_names = set()
            for item in primary_key:
                if not isinstance(item, str) or item not in column_names:
                    problems.append(f"{location}.primary_key references an unknown column.")
                elif item in primary_key_names:
                    problems.append(f"{location}.primary_key entries must be unique.")
                else:
                    primary_key_names.add(item)
        for column_name in sorted(auto_increment_columns):
            if column_name not in primary_key_names or column_types.get(column_name) not in MYSQL_INTEGER_TYPES:
                problems.append(f"MySQL auto_increment column {column_name} must be an integer primary-key column.")

        indexes = table.get("indexes", [])
        if indexes is None:
            indexes = []
        if not isinstance(indexes, list) or len(indexes) > 16:
            problems.append(f"{location}.indexes must be an array with at most 16 entries.")
            continue
        index_names: set[str] = set()
        for index_index, index in enumerate(indexes):
            index_location = f"{location}.indexes[{index_index}]"
            if not isinstance(index, dict):
                problems.append(f"{index_location} must be an object.")
                continue
            allowed_index = {"name", "columns", "unique"}
            unknown_index = sorted(set(index) - allowed_index)
            if unknown_index:
                problems.append(f"{index_location} has unknown fields: {', '.join(unknown_index)}.")
            index_name = index.get("name")
            if not isinstance(index_name, str) or not MYSQL_IDENTIFIER.fullmatch(index_name):
                problems.append(f"{index_location}.name must be a valid logical index name.")
            elif index_name in index_names:
                problems.append(f"MySQL schema index name is duplicated in {table_name}: {index_name}.")
            else:
                index_names.add(index_name)
            index_columns = index.get("columns")
            if not isinstance(index_columns, list) or not index_columns:
                problems.append(f"{index_location}.columns must be a non-empty array.")
                continue
            seen_index_columns: set[str] = set()
            for column_name in index_columns:
                if not isinstance(column_name, str) or column_name not in column_names:
                    problems.append(f"{index_location}.columns references an unknown column.")
                elif column_name in seen_index_columns:
                    problems.append(f"{index_location}.columns entries must be unique.")
                else:
                    seen_index_columns.add(column_name)
            if "unique" in index and not isinstance(index["unique"], bool):
                problems.append(f"{index_location}.unique must be boolean when present.")
    return problems


def hosting_contract_errors(contract: dict, profile: str, root: Path) -> list[str]:
    problems: list[str] = []
    allowed = {"schema_version", "project_id", "runtime_profile", "overrides", "required_env", "capabilities"}
    unknown = sorted(set(contract) - allowed)
    if unknown:
        problems.append(f"Hosting contract has unknown fields: {', '.join(unknown)}.")
    if contract.get("schema_version") != "1.0":
        problems.append("Hosting contract schema_version must be 1.0.")
    project_id = contract.get("project_id")
    if project_id is not None and (not isinstance(project_id, str) or not PROJECT_ID.fullmatch(project_id)):
        problems.append("project_id must be null or prj_ followed by a 26-character lowercase Crockford ULID.")
    if contract.get("runtime_profile") != profile:
        problems.append("Hosting contract runtime_profile disagrees with project detection.")
    required_env = contract.get("required_env")
    if not isinstance(required_env, list) or len(required_env) > 128:
        problems.append("required_env must be an array with at most 128 entries.")
    elif any(not isinstance(key, str) or not ENV_KEY.fullmatch(key) for key in required_env):
        problems.append("required_env contains an invalid environment key.")
    elif len(required_env) != len(set(required_env)):
        problems.append("required_env entries must be unique.")
    elif RESERVED_MYSQL_ENV_KEYS.intersection(required_env):
        problems.append("required_env must not contain reserved WEGENT_MYSQL_* keys.")
    overrides = contract.get("overrides")
    if overrides is not None:
        if not isinstance(overrides, dict) or not overrides:
            problems.append("overrides must be a non-empty object when present.")
        else:
            override_allowed = {"frontend_dir", "backend_dir", "python_entrypoint"}
            extra = sorted(set(overrides) - override_allowed)
            if extra:
                problems.append(f"overrides has unknown fields: {', '.join(extra)}.")
            for key in ("frontend_dir", "backend_dir"):
                if key in overrides and not valid_relative_path(overrides[key]):
                    problems.append(f"overrides.{key} must be a safe project-relative path.")
            entrypoint = overrides.get("python_entrypoint")
            if entrypoint is not None and (
                not isinstance(entrypoint, str)
                or len(entrypoint) > 256
                or not PYTHON_ENTRYPOINT.fullmatch(entrypoint)
            ):
                problems.append("overrides.python_entrypoint is invalid.")
    capabilities = contract.get("capabilities")
    if capabilities is not None:
        if not isinstance(capabilities, dict) or not capabilities:
            problems.append("capabilities must be a non-empty object when present.")
        else:
            capability_allowed = {"mysql"}
            extra = sorted(set(capabilities) - capability_allowed)
            if extra:
                problems.append(f"capabilities has unknown fields: {', '.join(extra)}.")
            mysql = capabilities.get("mysql")
            if mysql is not None:
                if not isinstance(mysql, dict):
                    problems.append("capabilities.mysql must be an object.")
                else:
                    mysql_allowed = {"enabled", "schema_file"}
                    extra_mysql = sorted(set(mysql) - mysql_allowed)
                    if extra_mysql:
                        problems.append(f"capabilities.mysql has unknown fields: {', '.join(extra_mysql)}.")
                    if mysql.get("enabled") is not True:
                        problems.append("capabilities.mysql.enabled must be true when MySQL is declared.")
                    if profile not in {"fastapi", "react-fastapi"}:
                        problems.append("capabilities.mysql is valid only for fastapi and react-fastapi projects.")
                    schema_file = mysql.get("schema_file")
                    if schema_file is not None:
                        if not valid_relative_path(schema_file):
                            problems.append("capabilities.mysql.schema_file must be a safe project-relative path.")
                        else:
                            schema_path = root / schema_file
                            try:
                                schema = load_json(schema_path)
                            except ValueError as exc:
                                problems.append(str(exc))
                            else:
                                problems.extend(validate_mysql_schema(schema))
    return problems


def validate(root: Path, run_build: bool) -> tuple[dict, dict]:
    detected = detect(root)
    profile = detected["profile"]
    checks: list[dict] = []
    errors: list[str] = []
    warnings = list(detected["risks"])
    contract_path = root / ".wegent/hosting.json"
    try:
        contract = load_json(contract_path)
        contract_problems = hosting_contract_errors(contract, profile, root)
        contract_ok = not contract_problems
        errors.extend(contract_problems)
    except ValueError as exc:
        contract, contract_ok = {}, False
        errors.append(str(exc))
    add_check(checks, "hosting_contract", contract_ok, "contract matches detected profile")
    if not contract_ok and not any(message.startswith("Hosting contract") or message.startswith("project_id") or message.startswith("required_env") or message.startswith("overrides") for message in errors):
        errors.append("Hosting contract is missing, invalid, or disagrees with detection.")

    frontend_dir = detected.get("frontend_dir")
    backend_dir = detected.get("backend_dir")
    package_root = root if frontend_dir in (None, ".") else root / frontend_dir

    if profile == "html":
        ok = (root / "index.html").is_file()
        add_check(checks, "html_entrypoint", ok, "index.html exists")
        if not ok: errors.append("index.html is required.")

    if profile in {"react-vite", "react-fastapi"}:
        package_path = package_root / "package.json"
        lock_path = package_root / "package-lock.json"
        try:
            package = load_json(package_path)
            has_build = isinstance(package.get("scripts"), dict) and bool(package["scripts"].get("build"))
        except ValueError as exc:
            package, has_build = {}, False
            errors.append(str(exc))
        add_check(checks, "npm_lockfile", lock_path.is_file(), "package-lock.json exists")
        add_check(checks, "frontend_build_script", has_build, "package.json defines build")
        if not lock_path.is_file(): errors.append("package-lock.json is required for npm builds.")
        if not has_build: errors.append("package.json must define scripts.build.")
        if run_build and not errors:
            completed = subprocess.run(
                ["npm", "run", "build"], cwd=package_root, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=300, check=False,
            )
            build_ok = completed.returncode == 0
            add_check(checks, "frontend_build", build_ok, completed.stdout[-2000:])
            if not build_ok: errors.append("npm run build failed.")
        elif not run_build:
            warnings.append("Frontend build was not executed; rerun with --run-build after installing dependencies.")

    if profile in {"fastapi", "react-fastapi"}:
        main_path = root / "backend/main.py"
        requirements = root / "requirements.txt"
        syntax_ok = False
        if main_path.is_file():
            try:
                py_compile.compile(str(main_path), doraise=True)
                syntax_ok = True
            except py_compile.PyCompileError as exc:
                errors.append(str(exc))
        add_check(checks, "python_syntax", syntax_ok, "backend/main.py compiles")
        requirements_ok = requirements.is_file() and "fastapi" in requirements.read_text(encoding="utf-8").lower()
        add_check(checks, "python_requirements", requirements_ok, "requirements.txt declares FastAPI")
        health_ok = main_path.is_file() and '"/health"' in main_path.read_text(encoding="utf-8")
        add_check(checks, "health_route", health_ok, "backend/main.py declares /health")
        if not syntax_ok: errors.append("backend/main.py must compile.")
        if not requirements_ok: errors.append("requirements.txt must declare FastAPI.")
        if not health_ok: errors.append("FastAPI application must declare /health.")

    if profile == "unknown":
        errors.append("Unsupported or unrecognized project.")

    passed = not errors
    manifest: dict = {
        "schema_version": "1.0",
        "runtime_profile": profile,
        "source_sha256": source_digest(root),
        "validation": {"passed": passed, "validator_version": VERSION},
    }
    if profile == "html":
        manifest.update({"frontend_dir": ".", "frontend_output": ".", "health_path": "/"})
    elif profile == "react-vite":
        manifest.update({
            "package_manager": "npm",
            "frontend_dir": ".",
            "frontend_build": ["npm", "run", "build"],
            "frontend_output": "dist",
            "health_path": "/",
        })
    elif profile == "fastapi":
        manifest.update({
            "backend_dir": backend_dir,
            "python_entrypoint": detected.get("python_entrypoint"),
            "health_path": "/health",
        })
    elif profile == "react-fastapi":
        manifest.update({
            "package_manager": "npm",
            "frontend_dir": frontend_dir,
            "backend_dir": backend_dir,
            "frontend_build": ["npm", "run", "build"],
            "frontend_output": "frontend/dist",
            "python_entrypoint": detected.get("python_entrypoint"),
            "health_path": "/health",
        })
    result = {
        "schema_version": "1.0",
        "passed": passed,
        "profile": profile,
        "errors": errors,
        "warnings": warnings,
        "checks": checks,
        "contract_digest": f"sha256:{hashlib.sha256(json.dumps(contract, sort_keys=True, separators=(',', ':')).encode()).hexdigest()}",
        "build_manifest": str(root / ".wegent/build-manifest.json"),
    }
    return result, manifest


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("directory", nargs="?", default=".")
    parser.add_argument("--run-build", action="store_true")
    args = parser.parse_args()
    root = Path(args.directory).resolve()
    if not root.is_dir(): parser.error(f"directory does not exist: {root}")
    result, manifest = validate(root, args.run_build)
    output = root / ".wegent/build-manifest.json"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
