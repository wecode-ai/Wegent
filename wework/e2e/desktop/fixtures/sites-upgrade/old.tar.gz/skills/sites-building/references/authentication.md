# Authentication

Do not create a project-local username/password system. Identity is supplied by the trusted Wegent
gateway. Application code may consume documented identity headers only when the platform confirms
their names and strips user-supplied copies. Treat authentication as unavailable during local
preview unless an explicit mock identity mode is clearly isolated from production.
