#!/usr/bin/env python3
"""Read-only, deterministic Wegent Sites project detection."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def load_json(path: Path) -> dict:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"cannot read JSON {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise ValueError(f"expected JSON object in {path}")
    return value


def detect(root: Path) -> dict:
    risks: list[str] = []
    contract_path = root / ".wegent/hosting.json"
    contract = load_json(contract_path) if contract_path.is_file() else None

    if contract and contract.get("runtime_profile") in {
        "html", "react-vite", "fastapi", "react-fastapi"
    }:
        profile = contract["runtime_profile"]
        confidence = "contract"
    elif (root / "frontend/package.json").is_file() and (root / "backend/main.py").is_file():
        profile, confidence = "react-fastapi", "high"
    elif (root / "backend/main.py").is_file() and (root / "requirements.txt").is_file():
        profile, confidence = "fastapi", "high"
    elif (root / "package.json").is_file():
        package = load_json(root / "package.json")
        dependencies = {**package.get("dependencies", {}), **package.get("devDependencies", {})}
        if "vite" in dependencies:
            profile, confidence = "react-vite", "high"
        else:
            profile, confidence = "unknown", "low"
            risks.append("Node project does not declare Vite.")
    elif (root / "index.html").is_file():
        profile, confidence = "html", "high"
    else:
        profile, confidence = "unknown", "none"
        risks.append("No supported project entrypoint was found.")

    frontend_dir = "frontend" if (root / "frontend").is_dir() else ("." if profile in {"html", "react-vite"} else None)
    backend_dir = "backend" if (root / "backend").is_dir() else None
    package_root = root / frontend_dir if frontend_dir not in (None, ".") else root
    package_manager = "none"
    if profile in {"react-vite", "react-fastapi"}:
        if (package_root / "package-lock.json").is_file():
            package_manager = "npm"
        else:
            package_manager = "unknown"
            risks.append("MVP Node builds require package-lock.json and npm.")
    if (root / "Dockerfile").exists():
        risks.append("A project Dockerfile exists but is not trusted by the MVP builder.")

    return {
        "schema_version": "1.0",
        "root": str(root),
        "profile": profile,
        "confidence": confidence,
        "frontend_dir": frontend_dir,
        "backend_dir": backend_dir,
        "python_entrypoint": "backend.main:app" if backend_dir else None,
        "package_manager": package_manager,
        "contract_path": str(contract_path) if contract_path.is_file() else None,
        "risks": risks,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("directory", nargs="?", default=".")
    args = parser.parse_args()
    root = Path(args.directory).resolve()
    if not root.is_dir():
        parser.error(f"directory does not exist: {root}")
    try:
        result = detect(root)
    except ValueError as exc:
        result = {"schema_version": "1.0", "profile": "unknown", "risks": [str(exc)]}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result.get("profile") != "unknown" else 1


if __name__ == "__main__":
    raise SystemExit(main())
