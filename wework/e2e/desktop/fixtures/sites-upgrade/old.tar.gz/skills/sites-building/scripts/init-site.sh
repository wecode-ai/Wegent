#!/usr/bin/env bash
set -euo pipefail

usage() {
  echo "usage: init-site.sh --profile html|react-vite|fastapi|react-fastapi <directory>" >&2
  exit 2
}

[[ $# -eq 3 && "$1" == "--profile" ]] || usage
profile="$2"
target="$3"
case "$profile" in
  html|react-vite|fastapi|react-fastapi) ;;
  *) usage ;;
esac

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
template_dir="$script_dir/../templates/$profile"

if [[ -e "$target" ]] && [[ -n "$(find "$target" -mindepth 1 -maxdepth 1 -print -quit 2>/dev/null)" ]]; then
  echo "target directory must be absent or empty: $target" >&2
  exit 1
fi

mkdir -p "$target"
cp -R "$template_dir/." "$target/"
echo "initialized $profile project at $target"
