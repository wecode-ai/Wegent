#!/usr/bin/env node
import { readFile, readdir } from "node:fs/promises";
import path from "node:path";

const root = path.resolve(process.argv[2] ?? ".");
const files = [];
async function walk(directory) {
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    if (["node_modules", "dist", ".git"].includes(entry.name)) continue;
    const target = path.join(directory, entry.name);
    if (entry.isDirectory()) await walk(target);
    else if (/\.(html|jsx|tsx|css)$/.test(entry.name)) files.push(target);
  }
}
await walk(root);
const content = (await Promise.all(files.map((file) => readFile(file, "utf8")))).join("\n");
const failures = [];
const warnings = [];
if (/Lorem ipsum|Feature 1|John Doe/i.test(content)) failures.push("generic placeholder content found");
if (!/viewport/i.test(content)) warnings.push("no viewport metadata found in scanned source");
if (!/<main|<main\b|role=["']main/i.test(content)) warnings.push("no main landmark found");
if (!/:focus-visible|:focus\b/.test(content)) warnings.push("no visible focus style found");
if (!/prefers-reduced-motion/.test(content)) warnings.push("no reduced-motion handling found");
console.log(JSON.stringify({ passed: failures.length === 0, files: files.length, failures, warnings }, null, 2));
process.exitCode = failures.length === 0 ? 0 : 1;
