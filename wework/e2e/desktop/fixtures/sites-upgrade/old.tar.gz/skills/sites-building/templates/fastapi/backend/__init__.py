"""Wegent Sites FastAPI application package."""
