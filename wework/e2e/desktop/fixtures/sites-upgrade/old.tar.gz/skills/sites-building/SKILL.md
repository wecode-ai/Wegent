---
name: sites-building
description: Build or adopt websites for Wegent Sites using the html, react-vite, fastapi, or react-fastapi runtime profiles. Always use when a project contains .wegent/hosting.json.
---

# Wegent Sites Building

Use this skill to create or modify a site and produce locally validated source. Do not publish from
this skill. Hosting actions belong to `sites-hosting`.

## Workflow

1. Read the user request and inspect the existing project before choosing a profile.
2. For a new project, choose the lightest profile that provides the required capability and run
   `scripts/init-site.sh --profile <profile> <directory>` from the plugin root.
3. For an existing project, never run the initializer. Run `scripts/detect-project.py <directory>`
   and preserve its structure, package manager, and lockfile.
4. Confirm audience, purpose, core behavior, content, and desired feel when those materially affect
   the result. Use `choose_site_design` only when three genuinely different directions would help.
5. Implement one coherent result. Use product-specific content and remove starter traces.
6. Run `scripts/validate-project.py <directory>`. For Node templates, also pass `--run-build` after
   dependencies are installed. Fix deterministic failures before proceeding.
7. For user-facing pages, run `node skills/sites-building/scripts/check-page-quality.mjs <directory>`.
8. Hand the validated directory and `.wegent/build-manifest.json` to `sites-hosting` only when the
   user asks to save a version or deploy.

## Runtime truth table

- `html`: native HTML/CSS/JS; no build required.
- `react-vite`: npm plus `package-lock.json`; CSS Modules or plain CSS; no Tailwind requirement.
- `fastapi`: `requirements.txt`, `backend.main:app`, and `/health`.
- `react-fastapi`: npm frontend plus FastAPI backend; one runtime image in MVP.
- Existing Vue static projects may be detected, but there is no Vue initializer in Phase 0.
- MySQL durable storage is supported only through the platform capability for `fastapi` and
  `react-fastapi`. Static-only `html` and `react-vite` sites do not connect directly to MySQL.
- Flask, Django, pyproject-only Python projects, arbitrary Dockerfiles, and unmanaged databases are
  not supported.

## Non-negotiable constraints

- API requests use relative `/api` paths. Never hard-code localhost into browser code.
- Secrets come from environment variables and must not enter source, prompts, logs, or images.
- Do not add custom username/password authentication. Follow `references/authentication.md`.
- Do not claim durable SQLite storage under delete-then-create deployment.
- When durable data is needed, declare `capabilities.mysql` and a logical schema file, then let
  `sites-hosting` call the MySQL MCP tools before saving the source revision.
- Treat `.wegent/hosting.json` as a constrained project association, not a command runner.
- Read only the runtime references needed for the selected profile.

## References

- Contract: `references/project-contract.md`
- Static profiles: `references/static-runtime.md`
- FastAPI: `references/fastapi-runtime.md`
- Full stack: `references/fullstack-runtime.md`
- Page quality: `references/page-quality.md`
- Authentication: `references/authentication.md`
- Persistence: `references/persistence.md`
