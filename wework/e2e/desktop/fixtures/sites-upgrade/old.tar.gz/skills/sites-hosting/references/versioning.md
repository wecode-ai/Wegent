# Versioning

The resource chain is Project → Source Revision → Build → Artifact → Version → Deployment.
Source Revision and Version are immutable. A project may have many saved Versions without an
online change. Environment variables are separately revisioned; a Deployment combines Version,
Environment Revision, target, and an access-policy snapshot.
