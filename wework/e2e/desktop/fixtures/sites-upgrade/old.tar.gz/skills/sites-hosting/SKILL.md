---
name: sites-hosting
description: Save immutable versions and deploy or roll back projects through Wegent Sites. Always use after sites-building when the user asks to save, publish, deploy, inspect, or roll back a site.
---

# Wegent Sites Hosting

This skill orchestrates the `wegent_apps` MCP tools for the Wegent Sites app/connector. The plugin
never calls the platform REST API directly and never substitutes `curl` when the connector is
unavailable.

## Invariants

1. Saving a version does not deploy it.
2. A Version is immutable and references a successful Build and immutable Artifact.
3. A Deployment references a Version; it never publishes a mutable directory or image tag.
4. Stable URLs belong to the Project.
5. Identity and permission come from trusted service credentials, never tool arguments such as
   `username` or `skip_security_check`.

## Workflow

1. Call `get_capabilities`; stop if contract major, runtime profile, or package size is unsupported.
2. Create or reuse the Project and update `.wegent/hosting.json` with the returned `project_id`.
3. Run `scripts/validate-project.py <directory>` after any `project_id` or contract edits. Require a
   successful local validation result and generated build manifest for the exact files that will be
   saved.
4. If `.wegent/hosting.json` enables `capabilities.mysql`, call `get_mysql_capability`; stop if it is
   disabled or does not support the detected runtime profile or schema version.
5. For MySQL projects, call `ensure_mysql_binding`. If a schema file is declared, read it, then call
   `plan_mysql_schema`. Explain non-empty changes or warnings when review is useful, and call
   `apply_mysql_schema` before saving the source revision. Use stable idempotency keys for binding
   and schema writes. Do not continue to source save if the MySQL plan/apply step fails.
6. Save a Source Revision from the exact validated files. Call `save_source_revision` with
   `source_directory` and `source_sha256`; the local executor validates metadata, creates a
   deterministic ZIP, sends `source_sha256`, `source_archive_sha256`, byte size, and archive payload
   through connector runtime, and the platform resolves the Source Revision. This local-path
   contract is available only through the executor-registered `mcp_servers.wegent_apps` MCP path;
   direct connector gateway, platform MCP, or desktop `runtime.connectors.call` callers must send the
   already packaged archive contract and cannot pass `source_directory`. If the upload is still
   processing, retry `save_source_revision` with the same Project and idempotency key to resume.
7. Create a Build and poll its status. Poll every 2 seconds for at most 10 minutes. Stop immediately
   on `failed` or `canceled`; show only the platform's redacted diagnostics.
8. When the Build succeeds, call `save_site_version`.
9. If the user requested only save/review, stop and report the Version. Do not create a Deployment.
10. For inner deployment, call `confirm_inner_site_access` before deployment. The first form defaults
   to `all` / “所有人” and also offers `owner` / “仅自己” and `custom` / “指定人”. If the user chooses
   `custom`, the tool asks for comma-separated usernames in a second form. If the user cancels or the
   tool returns anything other than `status="confirmed"`, stop without deploying.
11. After inner access is confirmed, call `update_site_access` for `target="inner"` with the selected
   `audience`. Pass `subjects` only for `audience="custom"`; omit it for `all` and `owner`. Then use
   the current inner Environment Revision. The platform selects the latest inner access policy and
   snapshots it onto the Deployment.
12. Outer deployments and outer access changes do not use the inner access confirmation form. The
    platform is authoritative for caller permissions, access policy changes, and `outer` security
    audit gates.
13. Deploy the chosen Version, then poll `get_deployment_status` with the returned `deployment_id`
   every 2 seconds for at most 10 minutes. For `outer`, the `deploy_site_version` return value only
   means the request was accepted for security audit; tell the user: "The publish request was
   submitted and is in security review. If it passes, publishing will continue; if it fails, the
   external publish will fail." Report external publish success only after `succeeded`. Treat
   `requested` and `policy_check` as security or publish checks in progress, even when the policy
   check is slow; treat `provisioning`, `health_check`, and `switching` as audit passed and publish
   in progress. On `failed` with `failure.code="SECURITY_REJECTED"`, report that the security audit
   rejected the external publish and no external traffic switch occurred. On any other failure,
   fetch bounded redacted logs and leave the prior stable route intact.
14. A rollback lists Versions, uses `choose_site_version`, explicitly selects a historical or current
    Environment Revision, and creates a new Deployment.

Default to `inner`. Do not pass `access_policy_id` when deploying; the platform snapshots the
selected policy onto the Deployment.
Automatically retry only
`TEMPORARY_UNAVAILABLE` and explicit transient network failures. Do not retry permission, quota,
validation, contract, build, or security failures blindly.

The plugin never runs Git commands and never handles GitLab repository URLs, refs, commits, tokens,
or source credential sessions. Those responsibilities belong to the Platform.

## References

- Version model: `references/versioning.md`
- Access control: `references/access-control.md`
- Failure and rollback behavior: `references/deployment-recovery.md`
