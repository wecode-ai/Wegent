# Access control

Before an inner deployment, call `confirm_inner_site_access` to ask the user to confirm the
intranet access audience. The first form defaults to `all` / “所有人”, and also offers `owner` /
“仅自己” and `custom` / “指定人”. If the user chooses `custom`, the tool asks for usernames in a
second form. Inner `custom` access requires a non-empty comma-separated `subjects` string containing
unique user email prefixes. Inner `all` and `owner` access do not accept `subjects`.

After the user confirms inner access, call `update_site_access` with `target="inner"` and the
selected `audience`; pass `subjects` only for `audience="custom"`. For outer access updates, omit
`audience` and `subjects`; the platform normalizes the stored policy to `audience=all` and
`subjects=[]`. Deployment callers must not pass `access_policy_id`; the platform selects the latest
policy for `project_id + target` and stores an immutable `access_snapshot_json` on the Deployment.

The platform remains authoritative for permissions, access policy changes, and security review.
Agents may summarize the target, audience, stable URL, and security status to the user.
