#!/usr/bin/env python3
"""Create a deterministic source archive without modifying the user's Git repository."""

from __future__ import annotations

import argparse
import hashlib
import json
import stat
import zipfile
from pathlib import Path

EXCLUDED_PARTS = {".git", "node_modules", "dist", "__pycache__", ".pytest_cache", ".DS_Store"}
MAX_FILE_BYTES = 25 * 1024 * 1024
MAX_FILES = 20_000


def included_files(root: Path) -> list[Path]:
    files: list[Path] = []
    for path in sorted(p for p in root.rglob("*") if p.is_file() or p.is_symlink()):
        rel = path.relative_to(root)
        if any(part in EXCLUDED_PARTS for part in rel.parts):
            continue
        if path.is_symlink():
            raise ValueError(f"symbolic links are not allowed in source packages: {rel}")
        if path.stat().st_size > MAX_FILE_BYTES:
            raise ValueError(f"file exceeds {MAX_FILE_BYTES} bytes: {rel}")
        files.append(path)
    if len(files) > MAX_FILES:
        raise ValueError(f"source contains more than {MAX_FILES} files")
    return files


def package(root: Path, output: Path) -> dict:
    files = included_files(root)
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for source in files:
            rel = source.relative_to(root).as_posix()
            info = zipfile.ZipInfo(rel, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (stat.S_IFREG | 0o644) << 16
            archive.writestr(info, source.read_bytes())
    digest = hashlib.sha256(output.read_bytes()).hexdigest()
    return {
        "schema_version": "1.0",
        "archive": str(output),
        "sha256": f"sha256:{digest}",
        "file_count": len(files),
        "size_bytes": output.stat().st_size,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("directory", nargs="?", default=".")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    root = Path(args.directory).resolve()
    output = Path(args.output).resolve()
    if not root.is_dir(): parser.error(f"directory does not exist: {root}")
    if output == root or root in output.parents:
        parser.error("output archive must be outside the source directory")
    try:
        result = package(root, output)
    except ValueError as exc:
        parser.error(str(exc))
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
